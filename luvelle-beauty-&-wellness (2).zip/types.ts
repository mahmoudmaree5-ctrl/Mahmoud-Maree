
export type Category = 'Hair' | 'Nails' | 'Massage' | 'Packages' | 'Skin';

export interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number; // For product-based offers
  duration: string;
  category: Category;
  image: string;
}

export interface CartItem extends Service {
  quantity: number;
}

export interface Address {
  id: string;
  label: string;
  street: string;
  city: string;
  isDefault: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export interface Preference {
  id: string;
  label: string;
  category: 'Ambiance' | 'Service' | 'Notification';
  enabled: boolean;
}

export interface Blog {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  image: string;
}

export interface Offer {
  id: string;
  title: string;
  description: string;
  code: string;
  discount: string;
  image: string;
}
