
import React, { useState, useEffect } from 'react';
import { AppProvider, useApp } from './AppContext';
import { ArrowRight, MapPin, History, CreditCard, Settings, ChevronLeft, Copy, Check, Star, Mail, Phone, Instagram, Facebook, Sparkles, Clock, Calendar, ShieldCheck, Heart, ShoppingBag, MessageCircle, Info, LogOut, User, Sparkle, Share2 } from 'lucide-react';
import HeaderBar from './components/HeaderBar';
import SideDrawer from './components/SideDrawer';
import BottomTabNav from './components/BottomTabNav';
import Home from './pages/Home';
import Services from './pages/Services';
import News from './pages/News';
import Booking from './pages/Booking';
import Auth from './pages/Auth';
import CartScreen from './pages/CartScreen';
import { Category, Blog, Service } from './types';
import { BLOGS, SERVICES } from './constants';
import LuxeImage from './components/LuxeImage';
import { getWhatsAppLink } from './utils/whatsapp';

type AppFlow = 'splash' | 'onboarding' | 'welcome' | 'main';

const handleShareApp = async () => {
  const shareData = {
    title: 'Luvelle Beauty & Wellness',
    text: 'Experience luxury beauty rituals at home with Luvelle.',
    url: window.location.href,
  };
  try {
    if (navigator.share) {
      await navigator.share(shareData);
    } else {
      await navigator.clipboard.writeText(window.location.href);
      alert('Link copied to sanctuary clipboard!');
    }
  } catch (err) {
    console.error('Error sharing:', err);
  }
};

const SplashScreen: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  useEffect(() => {
    const timer = setTimeout(onComplete, 2500);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[100] bg-[#FFFBFD] flex flex-col items-center justify-center animate-fade-in">
      <div className="relative">
        <div className="absolute inset-0 bg-rose-200 blur-3xl opacity-20 animate-pulse" />
        <div className="relative z-10 space-y-4 text-center">
          <div className="text-5xl font-serif font-black text-rose-500 tracking-tighter animate-slide-in-up">LUVELLE</div>
          <div className="text-[10px] font-black text-rose-300 uppercase tracking-[0.4em] opacity-0 animate-fade-in" style={{ animationDelay: '0.5s', animationFillMode: 'forwards' }}>
            Sanctuary at Home
          </div>
        </div>
      </div>
    </div>
  );
};

const OnboardingScreen: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [step, setStep] = useState(0);
  const slides = [
    {
      title: "Your Personal Sanctuary",
      desc: "Experience elite beauty rituals in the comfort of your own home.",
      img: "https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=800&fit=crop"
    },
    {
      title: "Expert Artisans",
      desc: "Hand-picked professionals dedicated to your wellness journey.",
      img: "https://images.unsplash.com/photo-1596178065887-1198b6174551?w=800&fit=crop"
    },
    {
      title: "Curated Luxury",
      desc: "Premium products and personalized care for the modern woman.",
      img: "https://images.unsplash.com/photo-1515377905703-c4788e51af15?w=800&fit=crop"
    }
  ];

  const next = () => {
    if (step < slides.length - 1) setStep(step + 1);
    else onComplete();
  };

  return (
    <div className="fixed inset-0 z-[90] bg-[#FFFBFD] flex flex-col animate-fade-in">
      <div className="relative h-[65vh] w-full overflow-hidden rounded-b-[4rem] shadow-2xl">
        {slides.map((s, i) => (
          <div key={i} className={`absolute inset-0 transition-all duration-1000 ease-out ${i === step ? 'opacity-100 scale-100' : 'opacity-0 scale-110 pointer-events-none'}`}>
            <LuxeImage src={s.img} alt={s.title} className="w-full h-full" />
            <div className="absolute inset-0 bg-gradient-to-t from-rose-900/60 to-transparent" />
          </div>
        ))}
      </div>
      <div className="flex-1 p-10 flex flex-col justify-between">
        <div className="space-y-4">
          <div className="flex gap-2 mb-2">
            {slides.map((_, i) => (
              <div key={i} className={`h-1 rounded-full transition-all duration-500 ${i === step ? 'w-8 bg-rose-500' : 'w-2 bg-rose-200'}`} />
            ))}
          </div>
          <h2 className="text-4xl font-serif font-black text-slate-800 uppercase tracking-tighter leading-none animate-slide-in-up">
            {slides[step].title}
          </h2>
          <p className="text-sm text-slate-400 font-medium leading-relaxed animate-fade-in">
            {slides[step].desc}
          </p>
        </div>
        <button 
          onClick={next}
          className="w-full h-[64px] bg-rose-500 text-white rounded-[2.2rem] font-black uppercase tracking-[0.2em] text-[11px] flex items-center justify-center gap-3 shadow-2xl shadow-rose-200 active-scale"
        >
          {step === slides.length - 1 ? 'Start Journey' : 'Next'} <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

const WelcomeScreen: React.FC<{ onLogin: () => void, onGuest: () => void }> = ({ onLogin, onGuest }) => {
  return (
    <div className="fixed inset-0 z-[80] bg-[#FFFBFD] p-10 flex flex-col justify-center space-y-12 animate-fade-in">
      <div className="text-center space-y-4">
        <div className="w-20 h-20 bg-rose-50 rounded-[2.5rem] flex items-center justify-center mx-auto text-rose-500 mb-6 shadow-xl shadow-rose-100 border border-rose-100">
          <Sparkle className="w-10 h-10" />
        </div>
        <h2 className="text-4xl font-serif font-black text-slate-800 uppercase tracking-tighter leading-none">Welcome to Luvelle</h2>
        <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest max-w-[240px] mx-auto leading-relaxed">
          Select how you'd like to experience your sanctuary
        </p>
      </div>

      <div className="space-y-4">
        <button 
          onClick={onLogin}
          className="w-full h-[64px] bg-rose-500 text-white rounded-[2.2rem] font-black uppercase tracking-[0.2em] text-[11px] shadow-2xl shadow-rose-200 active-scale"
        >
          Sign In / Register
        </button>
        <button 
          onClick={onGuest}
          className="w-full h-[64px] bg-white border border-rose-100 text-slate-400 rounded-[2.2rem] font-black uppercase tracking-[0.2em] text-[11px] active-scale"
        >
          Browse as Guest
        </button>
      </div>

      <p className="text-center text-[9px] text-slate-300 font-bold uppercase tracking-widest">
        By continuing you agree to our Terms of Luxury
      </p>
    </div>
  );
};

const AppContent: React.FC = () => {
  const [flow, setFlow] = useState<AppFlow>('splash');
  const [currentPage, setCurrentPage] = useState('home');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [initialCategory, setInitialCategory] = useState<Category | 'All'>('All');
  const [selectedJournal, setSelectedJournal] = useState<Blog | null>(null);
  const [selectedBooking, setSelectedBooking] = useState<any | null>(null);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const { user } = useApp();

  const handleNavigate = (page: string, category: Category | 'All' = 'All') => {
    setInitialCategory(category);
    setCurrentPage(page);
    window.scrollTo(0, 0);
  };

  const handleJournalDetail = (blog: Blog) => {
    setSelectedJournal(blog);
    setCurrentPage('journal-detail');
    window.scrollTo(0, 0);
  };

  const handleBookingDetail = (booking: any) => {
    setSelectedBooking(booking);
    setCurrentPage('booking-details');
    window.scrollTo(0, 0);
  };

  const handleServiceDetail = (service: Service) => {
    setSelectedService(service);
    setCurrentPage('service-detail');
    window.scrollTo(0, 0);
  };

  const renderPage = () => {
    // Auth Guard - only truly sensitive pages
    const protectedPages = ['booking', 'addresses', 'history', 'add-address', 'preferences', 'booking-details'];
    if (protectedPages.includes(currentPage) && !user) {
      return <Auth onNavigate={setCurrentPage} />;
    }

    switch (currentPage) {
      case 'home': return <Home onNavigate={handleNavigate} onServiceClick={handleServiceDetail} onBlogClick={handleJournalDetail} />;
      case 'services': return <Services initialCategory={initialCategory} onServiceClick={handleServiceDetail} />;
      case 'cart': return <CartScreen onCheckout={() => setCurrentPage('booking')} />;
      case 'booking': return <Booking onComplete={() => setCurrentPage('home')} />;
      case 'news': return <News onBlogClick={handleJournalDetail} />;
      case 'profile': return <ProfileScreen onNavigate={setCurrentPage} />;
      case 'offers': return <OffersScreen onServiceClick={handleServiceDetail} />;
      case 'about': return <AboutScreen onBack={() => setCurrentPage('profile')} />;
      case 'contact': return <ContactScreen onBack={() => setCurrentPage('profile')} />;
      case 'addresses': return <AddressesScreen onBack={() => setCurrentPage('profile')} onAdd={() => setCurrentPage('add-address')} />;
      case 'add-address': return <AddAddressScreen onBack={() => setCurrentPage('addresses')} />;
      case 'history': return <HistoryScreen onBack={() => setCurrentPage('profile')} onBookingClick={handleBookingDetail} />;
      case 'booking-details': return <BookingDetailsScreen booking={selectedBooking} onBack={() => setCurrentPage('history')} />;
      case 'preferences': return <PreferencesScreen onBack={() => setCurrentPage('profile')} />;
      case 'journal-detail': return <JournalDetailScreen blog={selectedJournal!} onBack={() => setCurrentPage('news')} />;
      case 'service-detail': return <ServiceDetailScreen service={selectedService!} onBack={() => setCurrentPage('services')} />;
      case 'auth': return <Auth onNavigate={setCurrentPage} />;
      default: return <Home onNavigate={handleNavigate} onServiceClick={handleServiceDetail} onBlogClick={handleJournalDetail} />;
    }
  };

  // Entry Flow Management
  if (flow === 'splash') return <SplashScreen onComplete={() => setFlow('onboarding')} />;
  if (flow === 'onboarding') return <OnboardingScreen onComplete={() => setFlow('welcome')} />;
  if (flow === 'welcome' && !user) return (
    <WelcomeScreen 
      onLogin={() => { setCurrentPage('auth'); setFlow('main'); }} 
      onGuest={() => setFlow('main')} 
    />
  );

  return (
    <div className="min-h-screen flex flex-col bg-[#FFFBFD] overflow-x-hidden">
      <HeaderBar 
        title={currentPage} 
        onOpenDrawer={() => setIsDrawerOpen(true)} 
        onNavigateToCart={() => setCurrentPage('cart')}
      />
      
      <main className="flex-1 pb-32 overflow-y-auto no-scrollbar">
        {renderPage()}
      </main>

      <SideDrawer 
        isOpen={isDrawerOpen} 
        onClose={() => setIsDrawerOpen(false)} 
        onNavigate={setCurrentPage} 
        onShare={handleShareApp}
      />
      
      <BottomTabNav onNavigate={setCurrentPage} currentPage={currentPage} />

      <style>{`
        @keyframes slide-in-left { from { transform: translateX(-100%); } to { transform: translateX(0); } }
        @keyframes slide-in-up { from { transform: translateY(40px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        @keyframes fade-in { from { opacity: 0; } to { opacity: 1; } }
        .animate-slide-in-left { animation: slide-in-left 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        .animate-slide-in-up { animation: slide-in-up 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        .animate-fade-in { animation: fade-in 0.5s ease-out forwards; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        body { -webkit-tap-highlight-color: transparent; overscroll-behavior-y: none; user-select: none; background-color: #FFFBFD; }
        .active-scale:active { transform: scale(0.96); transition: transform 0.1s ease; }
      `}</style>
    </div>
  );
};

const ServiceDetailScreen = ({ service, onBack }: { service: Service, onBack: () => void }) => {
  const { addToCart } = useApp();
  return (
    <div className="animate-fade-in pb-24">
      <div className="relative h-[450px]">
        <LuxeImage src={service.image} className="w-full h-full" alt={service.name} />
        <div className="absolute inset-0 bg-gradient-to-t from-[#FFFBFD] via-transparent to-transparent" />
        <button onClick={onBack} className="absolute top-8 left-8 w-12 h-12 bg-white/40 backdrop-blur-md rounded-2xl text-white border border-white/20 flex items-center justify-center active-scale">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <button className="absolute top-8 right-8 w-12 h-12 bg-white/40 backdrop-blur-md rounded-2xl text-white border border-white/20 flex items-center justify-center active-scale">
          <Heart className="w-6 h-6" />
        </button>
        
        <div className="absolute bottom-0 left-0 right-0 p-8 space-y-4">
          <div className="flex gap-2">
            <span className="px-4 py-2 bg-rose-500 text-white rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg">
              {service.category}
            </span>
            {service.originalPrice && (
              <span className="px-4 py-2 bg-white text-rose-500 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> Special Offer
              </span>
            )}
          </div>
          <h1 className="text-4xl font-serif font-black text-slate-800 leading-tight tracking-tighter uppercase">{service.name}</h1>
        </div>
      </div>

      <div className="px-8 space-y-8">
        <div className="flex items-center justify-between py-6 border-y border-rose-50">
          <div className="flex items-center gap-6">
            <div className="space-y-1">
              <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest">Price</span>
              <div className="flex items-baseline gap-2">
                <p className="text-2xl font-black text-rose-500">${service.price}</p>
                {service.originalPrice && (
                  <p className="text-sm font-bold text-slate-300 line-through">${service.originalPrice}</p>
                )}
              </div>
            </div>
            <div className="w-px h-10 bg-rose-50" />
            <div className="space-y-1">
              <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest">Duration</span>
              <p className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-rose-300" /> {service.duration}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1 text-rose-400">
            <Star className="w-4 h-4 fill-rose-400" />
            <span className="text-sm font-black">4.9</span>
            <span className="text-[10px] text-slate-300 font-bold">(128)</span>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">About this Ritual</h3>
          <p className="text-[15px] text-slate-500 leading-relaxed font-medium">
            {service.description} Our professional artisans bring everything needed for this experience. We recommend setting aside a quiet, well-lit area in your home to ensure the most tranquil atmosphere.
          </p>
        </div>

        <div className="bg-rose-50/50 p-6 rounded-[2.5rem] border border-rose-100 flex items-center gap-4">
          <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-rose-400 shadow-sm">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div className="space-y-0.5">
            <p className="text-[11px] font-black text-slate-800 uppercase tracking-widest">Luvelle Promise</p>
            <p className="text-[10px] text-slate-400 font-bold">Vetted artisans & premium products.</p>
          </div>
        </div>

        <div className="space-y-4 pt-4">
          <button 
            onClick={() => addToCart(service)}
            className="w-full h-[64px] bg-gradient-to-r from-rose-400 to-rose-600 text-white rounded-[2.2rem] font-black uppercase tracking-[0.2em] text-[11px] flex items-center justify-center gap-3 shadow-2xl shadow-rose-200 active-scale"
          >
            <ShoppingBag className="w-5 h-5" /> Add to Bag
          </button>
          <a 
            href={getWhatsAppLink([{ ...service, quantity: 1 }])}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full h-[64px] bg-white border border-[#25D366]/30 text-[#25D366] rounded-[2.2rem] text-[11px] font-black uppercase tracking-[0.2em] flex items-center justify-center gap-3 active-scale"
          >
            <MessageCircle className="w-5 h-5" /> Book via WhatsApp
          </a>
        </div>
      </div>
    </div>
  );
};

const OffersScreen = ({ onServiceClick }: { onServiceClick: (s: Service) => void }) => {
  const saleServices = SERVICES.filter(s => s.originalPrice);

  return (
    <div className="p-8 space-y-10 animate-slide-in-up pb-24">
      <div className="space-y-1">
        <h2 className="text-3xl font-serif font-black text-slate-800 uppercase tracking-tighter">Exclusive Offers</h2>
        <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">Rituals with special pricing</p>
      </div>
      
      <div className="space-y-6">
        {saleServices.map(service => (
          <div key={service.id} className="bg-white rounded-[2.5rem] overflow-hidden border border-rose-100 shadow-xl shadow-rose-100/20 group active-scale" onClick={() => onServiceClick(service)}>
            <div className="h-48 relative">
              <img src={service.image} className="w-full h-full object-cover" alt={service.name} />
              <div className="absolute top-4 left-4 bg-rose-500 text-white text-[9px] font-black uppercase tracking-widest px-3 py-1.5 rounded-full shadow-lg">
                SAVE ${service.originalPrice! - service.price}
              </div>
            </div>
            <div className="p-6 flex justify-between items-center">
              <div className="space-y-1">
                <h4 className="font-bold text-slate-800 text-sm uppercase tracking-tight">{service.name}</h4>
                <div className="flex items-center gap-2">
                  <span className="text-rose-500 font-black text-lg">${service.price}</span>
                  <span className="text-slate-300 text-xs line-through font-bold">${service.originalPrice}</span>
                </div>
              </div>
              <div className="w-10 h-10 bg-rose-50 rounded-xl flex items-center justify-center text-rose-500">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-rose-50/50 p-8 rounded-[2.5rem] border border-dashed border-rose-200 text-center space-y-3">
        <Star className="w-6 h-6 text-rose-300 mx-auto" />
        <h4 className="text-sm font-bold text-slate-700">Membership Benefit</h4>
        <p className="text-[11px] text-slate-400 leading-relaxed font-medium">As a Signature Member, you receive these curated ritual offers automatically applied at checkout.</p>
      </div>
    </div>
  );
}

const AddAddressScreen = ({ onBack }: { onBack: () => void }) => (
  <div className="p-8 space-y-8 animate-slide-in-up">
    <div className="flex items-center gap-4">
      <button onClick={onBack} className="p-2.5 bg-white rounded-2xl shadow-sm border border-rose-50 text-rose-500 active-scale">
        <ChevronLeft className="w-5 h-5" />
      </button>
      <div className="space-y-0.5">
        <h2 className="text-2xl font-serif font-black text-slate-800 uppercase tracking-tighter">Add Sanctuary</h2>
        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">New Address Details</p>
      </div>
    </div>

    <form className="bg-white p-10 rounded-[3.5rem] shadow-2xl shadow-rose-100/30 border border-rose-50 space-y-8">
      <div className="space-y-6">
        <div className="space-y-1.5">
          <label className="text-[10px] font-black text-rose-300 uppercase tracking-widest ml-4">Address Label</label>
          <input className="w-full bg-rose-50/30 rounded-2xl px-6 py-4.5 text-sm font-medium outline-none border border-rose-100 focus:ring-4 focus:ring-rose-50 transition-all" placeholder="e.g. Work, Summer House" />
        </div>
        <div className="space-y-1.5">
          <label className="text-[10px] font-black text-rose-300 uppercase tracking-widest ml-4">Street & Number</label>
          <input className="w-full bg-rose-50/30 rounded-2xl px-6 py-4.5 text-sm font-medium outline-none border border-rose-100 focus:ring-4 focus:ring-rose-50 transition-all" placeholder="123 Luxury Ln" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-rose-300 uppercase tracking-widest ml-4">Apt / Suite</label>
            <input className="w-full bg-rose-50/30 rounded-2xl px-6 py-4.5 text-sm font-medium outline-none border border-rose-100 focus:ring-4 focus:ring-rose-50 transition-all" placeholder="B-12" />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-rose-300 uppercase tracking-widest ml-4">City</label>
            <input className="w-full bg-rose-50/30 rounded-2xl px-6 py-4.5 text-sm font-medium outline-none border border-rose-100 focus:ring-4 focus:ring-rose-50 transition-all" placeholder="Beverly Hills" />
          </div>
        </div>
      </div>
      <button type="button" onClick={onBack} className="w-full py-6 bg-gradient-to-r from-rose-400 to-rose-600 text-white rounded-[2.2rem] font-black uppercase tracking-[0.2em] text-[11px] shadow-xl shadow-rose-200 active-scale">Save Sanctuary</button>
    </form>
  </div>
);

const PreferencesScreen = ({ onBack }: { onBack: () => void }) => {
  const [prefs, setPrefs] = useState([
    { id: '1', label: 'Aromatherapy (Lavender Signature)', active: true },
    { id: '2', label: 'Ambient Soft Jazz Music', active: true },
    { id: '3', label: 'Female Artisan Preference', active: false },
    { id: '4', label: 'Quiet Ritual (No Conversation)', active: false },
    { id: '5', label: 'SMS Reminders', active: true },
  ]);

  const toggle = (id: string) => {
    setPrefs(prev => prev.map(p => p.id === id ? { ...p, active: !p.active } : p));
  };

  return (
    <div className="p-8 space-y-8 animate-slide-in-up">
      <div className="flex items-center gap-4">
        <button onClick={onBack} className="p-2.5 bg-white rounded-2xl shadow-sm border border-rose-50 text-rose-500 active-scale">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="space-y-0.5">
          <h2 className="text-2xl font-serif font-black text-slate-800 uppercase tracking-tighter">Preferences</h2>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Personalize your experience</p>
        </div>
      </div>

      <div className="space-y-4">
        {prefs.map(p => (
          <button key={p.id} onClick={() => toggle(p.id)} className="w-full p-6 bg-white rounded-[2.5rem] border border-rose-50 shadow-sm flex justify-between items-center active-scale">
            <span className={`text-sm font-bold tracking-tight ${p.active ? 'text-slate-800' : 'text-slate-400'}`}>{p.label}</span>
            <div className={`w-12 h-6 rounded-full transition-all flex items-center px-1 ${p.active ? 'bg-rose-500' : 'bg-slate-100'}`}>
              <div className={`w-4 h-4 bg-white rounded-full shadow-sm transition-all ${p.active ? 'translate-x-6' : 'translate-x-0'}`} />
            </div>
          </button>
        ))}
      </div>
      <button onClick={onBack} className="w-full py-6 bg-rose-500 text-white rounded-[2.2rem] font-black uppercase tracking-[0.2em] text-[11px] shadow-xl shadow-rose-200">Save My Aura</button>
    </div>
  );
};

const JournalDetailScreen = ({ blog, onBack }: { blog: Blog, onBack: () => void }) => (
  <div className="animate-fade-in pb-24">
    <div className="relative h-96">
      <img src={blog.image} className="w-full h-full object-cover" alt={blog.title} />
      <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent" />
      <button onClick={onBack} className="absolute top-8 left-8 p-3 bg-white/20 backdrop-blur-md rounded-2xl text-white border border-white/20 active-scale">
        <ChevronLeft className="w-6 h-6" />
      </button>
      <div className="absolute bottom-8 left-8 right-8 text-white space-y-4">
        <div className="flex items-center gap-4 text-[10px] font-bold uppercase tracking-[0.3em] opacity-80">
          <span className="flex items-center gap-1.5"><Clock className="w-4 h-4" /> {blog.date}</span>
          <span className="flex items-center gap-1.5"><Star className="w-4 h-4" /> Editorial</span>
        </div>
        <h1 className="text-4xl font-serif font-black leading-tight tracking-tighter uppercase">{blog.title}</h1>
      </div>
    </div>
    <div className="p-8 lg:p-12 space-y-8 bg-[#FFFBFD]">
      <div className="flex items-center gap-4 border-b border-rose-50 pb-8">
        <div className="w-12 h-12 bg-rose-100 rounded-full flex items-center justify-center text-rose-500 font-black text-xs">{blog.author.charAt(0)}</div>
        <div className="space-y-0.5">
          <p className="text-xs font-black uppercase tracking-widest text-slate-800">{blog.author}</p>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Lead Wellness Director</p>
        </div>
      </div>
      <div className="space-y-6">
        <p className="text-lg font-serif italic text-slate-700 leading-relaxed border-l-4 border-rose-200 pl-6">{blog.excerpt}</p>
        <p className="text-[15px] text-slate-600 leading-loose font-medium">{blog.content}</p>
        <p className="text-[15px] text-slate-600 leading-loose font-medium">To truly experience these benefits, we recommend our monthly subscription rituals which ensure consistency in your glow. Every Luvelle treatment is a step towards your most authentic self.</p>
      </div>
      <div className="pt-8">
        <button onClick={handleShareApp} className="flex items-center gap-3 text-rose-500 font-black text-xs uppercase tracking-[0.3em] group">
          Share Ritual <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-all" />
        </button>
      </div>
    </div>
  </div>
);

const BookingDetailsScreen = ({ booking, onBack }: { booking: any, onBack: () => void }) => (
  <div className="p-8 space-y-10 animate-slide-in-up">
    <div className="flex items-center gap-4">
      <button onClick={onBack} className="p-2.5 bg-white rounded-2xl shadow-sm border border-rose-50 text-rose-500 active-scale">
        <ChevronLeft className="w-5 h-5" />
      </button>
      <div className="space-y-0.5">
        <h2 className="text-2xl font-serif font-black text-slate-800 uppercase tracking-tighter">Ritual Details</h2>
        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Booking ID: LV-88912</p>
      </div>
    </div>

    <div className="space-y-6">
      <div className="bg-white p-10 rounded-[3.5rem] shadow-2xl shadow-rose-100/30 border border-rose-50 space-y-8 text-center">
        <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center text-green-500 mx-auto shadow-sm">
          <ShieldCheck className="w-10 h-10" />
        </div>
        <div className="space-y-2">
          <h3 className="text-2xl font-serif font-black text-slate-800 uppercase tracking-tighter">Ritual Completed</h3>
          <p className="text-xs text-slate-400 font-medium uppercase tracking-[0.2em]">October 14, 2024</p>
        </div>
        <div className="w-full h-px bg-rose-50" />
        <div className="grid grid-cols-2 gap-8 text-left">
          <div className="space-y-1">
            <span className="text-[9px] font-black text-rose-300 uppercase tracking-widest">Ritual</span>
            <p className="text-sm font-bold text-slate-800">Royal Blowout</p>
          </div>
          <div className="space-y-1">
            <span className="text-[9px] font-black text-rose-300 uppercase tracking-widest">Artisan</span>
            <p className="text-sm font-bold text-slate-800">Sarah M.</p>
          </div>
          <div className="space-y-1">
            <span className="text-[9px] font-black text-rose-300 uppercase tracking-widest">Sanctuary</span>
            <p className="text-sm font-bold text-slate-800 truncate">Main Sanctuary</p>
          </div>
          <div className="space-y-1">
            <span className="text-[9px] font-black text-rose-300 uppercase tracking-widest">Total</span>
            <p className="text-sm font-bold text-slate-800">$160.00</p>
          </div>
        </div>
      </div>

      <div className="bg-rose-50/30 p-8 rounded-[3rem] border border-rose-100 space-y-4">
        <h4 className="font-black text-slate-800 text-[10px] uppercase tracking-widest">Review your Artisan</h4>
        <div className="flex justify-between text-rose-200">
          {[1,2,3,4,5].map(i => <Star key={i} className={`w-8 h-8 ${i <= 5 ? 'fill-rose-400 text-rose-400' : ''}`} />)}
        </div>
      </div>
    </div>

    <button onClick={() => window.location.reload()} className="w-full py-6 bg-gradient-to-r from-rose-400 to-rose-600 text-white rounded-[2.2rem] font-black uppercase tracking-[0.2em] text-[11px] shadow-xl shadow-rose-200">Rebook this Ritual</button>
  </div>
);

const AboutScreen = ({ onBack }: { onBack: () => void }) => (
  <div className="p-8 space-y-12 animate-slide-in-up pb-24">
    <div className="flex items-center gap-4">
      <button onClick={onBack} className="p-2.5 bg-white rounded-2xl shadow-sm border border-rose-50 text-rose-500 active-scale">
        <ChevronLeft className="w-5 h-5" />
      </button>
      <div className="space-y-0.5">
        <h2 className="text-2xl font-serif font-black text-slate-800 uppercase tracking-tighter">Our Story</h2>
        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">The Luvelle Philosophy</p>
      </div>
    </div>
    
    <div className="relative h-80 rounded-[4rem] overflow-hidden shadow-2xl">
      <img src="https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=800&fit=crop" className="w-full h-full object-cover" alt="Spa environment" />
      <div className="absolute inset-0 bg-gradient-to-t from-rose-900/60 to-transparent" />
      <div className="absolute bottom-8 left-8 right-8 text-white">
        <p className="text-lg font-serif italic leading-tight">"Where your comfort meets our craftsmanship."</p>
      </div>
    </div>

    <div className="space-y-10">
      <div className="flex gap-6 items-start">
        <div className="w-12 h-12 bg-rose-50 rounded-2xl flex items-center justify-center text-rose-400 flex-shrink-0 shadow-sm border border-rose-100">01</div>
        <div className="space-y-2 pt-1">
          <h4 className="font-bold text-slate-800 text-sm uppercase tracking-tight">The Vision</h4>
          <p className="text-[13px] text-slate-500 leading-relaxed font-medium">To eliminate the friction of luxury by bringing high-end spa services directly to the modern woman's door.</p>
        </div>
      </div>
      <div className="flex gap-6 items-start">
        <div className="w-12 h-12 bg-rose-50 rounded-2xl flex items-center justify-center text-rose-400 flex-shrink-0 shadow-sm border border-rose-100">02</div>
        <div className="space-y-2 pt-1">
          <h4 className="font-bold text-slate-800 text-sm uppercase tracking-tight">The Artisans</h4>
          <p className="text-[13px] text-slate-500 leading-relaxed font-medium">Our specialists are vetted through a rigorous 3-stage luxury standard process to ensure elite performance.</p>
        </div>
      </div>
    </div>

    <div className="bg-white p-10 rounded-[3rem] border border-rose-100 shadow-xl shadow-rose-50 text-center">
      <div className="w-16 h-16 bg-rose-500 rounded-full flex items-center justify-center text-white mx-auto mb-6 shadow-lg shadow-rose-200">
        <Check className="w-8 h-8" />
      </div>
      <h3 className="text-xl font-serif font-black text-slate-800 uppercase tracking-tighter mb-2">Verified Excellence</h3>
      <p className="text-xs text-slate-400 leading-relaxed font-medium">Every Luvelle partner is insured, licensed, and specialized in high-end ritual delivery.</p>
    </div>
  </div>
);

const ContactScreen = ({ onBack }: { onBack: () => void }) => (
  <div className="p-8 space-y-10 animate-slide-in-up pb-24">
    <div className="flex items-center gap-4">
      <button onClick={onBack} className="p-2.5 bg-white rounded-2xl shadow-sm border border-rose-50 text-rose-500 active-scale">
        <ChevronLeft className="w-5 h-5" />
      </button>
      <div className="space-y-0.5">
        <h2 className="text-2xl font-serif font-black text-slate-800 uppercase tracking-tighter">Concierge</h2>
        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Personal assistance</p>
      </div>
    </div>

    <div className="grid grid-cols-2 gap-4">
      <div className="bg-white p-6 rounded-[2.5rem] border border-rose-50 shadow-sm flex flex-col items-center gap-3 text-center">
        <div className="w-10 h-10 bg-rose-50 rounded-xl flex items-center justify-center text-rose-400"><Mail className="w-5 h-5" /></div>
        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Email</span>
        <span className="text-[11px] font-bold text-slate-800 truncate w-full">concierge@luvelle.com</span>
      </div>
      <div className="bg-white p-6 rounded-[2.5rem] border border-rose-50 shadow-sm flex flex-col items-center gap-3 text-center">
        <div className="w-10 h-10 bg-rose-50 rounded-xl flex items-center justify-center text-rose-400"><Phone className="w-5 h-5" /></div>
        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Phone</span>
        <span className="text-[11px] font-bold text-slate-800">+1 800 LUVELLE</span>
      </div>
    </div>

    <div className="bg-white p-10 rounded-[3.5rem] shadow-2xl shadow-rose-100/30 border border-rose-50 space-y-8">
      <div className="space-y-5">
        <div className="space-y-1.5">
          <label className="text-[10px] font-black text-rose-300 uppercase tracking-widest ml-4">Subject</label>
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {['Booking', 'Special Request', 'Feedback', 'General'].map(s => (
              <button key={s} className="px-5 py-2.5 rounded-full bg-rose-50 text-rose-500 text-[10px] font-bold uppercase tracking-widest whitespace-nowrap border border-rose-100">
                {s}
              </button>
            ))}
          </div>
        </div>
        <div className="space-y-1.5">
          <label className="text-[10px] font-black text-rose-300 uppercase tracking-widest ml-4">Your Inquiry</label>
          <textarea rows={4} className="w-full bg-rose-50/30 rounded-[2rem] px-6 py-5 text-sm outline-none border border-rose-100 focus:ring-4 focus:ring-rose-50 transition-all resize-none" placeholder="How can we assist you today?" />
        </div>
      </div>
      <button className="w-full py-6 bg-gradient-to-r from-rose-400 to-rose-600 text-white rounded-[2.2rem] font-black uppercase tracking-[0.2em] text-[11px] shadow-xl shadow-rose-200 active-scale">Submit Inquiry</button>
    </div>

    <div className="flex justify-center gap-6 pt-4 opacity-40">
      <Instagram className="w-5 h-5" />
      <Facebook className="w-5 h-5" />
      <span className="text-xs font-bold font-serif italic tracking-widest">Luvelle Rituals</span>
    </div>
  </div>
);

const AddressesScreen = ({ onBack, onAdd }: { onBack: () => void, onAdd: () => void }) => (
  <div className="p-8 space-y-8 animate-slide-in-up">
    <div className="flex items-center gap-4">
      <button onClick={onBack} className="p-2.5 bg-white rounded-2xl shadow-sm border border-rose-50 text-rose-500 active-scale">
        <ChevronLeft className="w-5 h-5" />
      </button>
      <div className="space-y-0.5">
        <h2 className="text-2xl font-serif font-black text-slate-800 uppercase tracking-tighter">My Sanctuaries</h2>
        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Saved Addresses</p>
      </div>
    </div>

    <div className="space-y-4">
      <div className="bg-white p-6 rounded-[2.5rem] border-2 border-rose-500 shadow-xl shadow-rose-50 flex justify-between items-center group">
        <div className="flex gap-4 items-start">
          <div className="w-10 h-10 rounded-xl bg-rose-50 flex items-center justify-center text-rose-500"><MapPin className="w-5 h-5" /></div>
          <div>
            <h4 className="font-bold text-slate-800 text-sm">Main Sanctuary</h4>
            <p className="text-[11px] text-slate-400 font-medium leading-relaxed">123 Rose Avenue, Beverly Hills, CA</p>
          </div>
        </div>
        <div className="w-3 h-3 bg-rose-500 rounded-full shadow-[0_0_10px_rgba(244,114,182,0.8)]" />
      </div>

      <button onClick={onAdd} className="w-full py-6 border-2 border-dashed border-rose-100 rounded-[2.5rem] text-rose-300 font-black text-[11px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-rose-50/30 transition-all active-scale">
        + Add New Sanctuary
      </button>
    </div>
  </div>
);

const HistoryScreen = ({ onBack, onBookingClick }: { onBack: () => void, onBookingClick: (b: any) => void }) => (
  <div className="p-8 space-y-8 animate-slide-in-up">
    <div className="flex items-center gap-4">
      <button onClick={onBack} className="p-2.5 bg-white rounded-2xl shadow-sm border border-rose-50 text-rose-500 active-scale">
        <ChevronLeft className="w-5 h-5" />
      </button>
      <div className="space-y-0.5">
        <h2 className="text-2xl font-serif font-black text-slate-800 uppercase tracking-tighter">Ritual History</h2>
        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Your wellness journey</p>
      </div>
    </div>

    <div className="space-y-5">
      <div 
        onClick={() => onBookingClick({})}
        className="bg-white p-6 rounded-[2.5rem] border border-rose-50 shadow-sm flex gap-5 active-scale cursor-pointer"
      >
        <div className="w-20 h-20 rounded-[1.8rem] bg-rose-50 overflow-hidden flex-shrink-0">
          <img src="https://images.unsplash.com/photo-1522337363553-5605d9308ee7?w=300&fit=crop" className="w-full h-full object-cover grayscale opacity-60" alt="Past service" />
        </div>
        <div className="flex-1 flex flex-col justify-center">
          <div className="flex justify-between items-start">
            <h4 className="font-bold text-slate-800 text-sm">Royal Blowout</h4>
            <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest">OCT 14</span>
          </div>
          <p className="text-[11px] text-slate-400 font-medium mt-1">Status: Completed</p>
          <div className="flex justify-between items-end mt-2">
            <span className="font-black text-rose-300 text-sm">$150</span>
            <button className="text-[9px] font-black text-rose-400 uppercase tracking-widest underline decoration-rose-100 underline-offset-4">Details</button>
          </div>
        </div>
      </div>
    </div>
  </div>
);

const ProfileScreen = ({ onNavigate }: { onNavigate: (p: string) => void }) => {
  const { user, logout } = useApp();
  
  if (!user) {
    return (
      <div className="p-8 space-y-10 animate-slide-in-up">
        <div className="text-center pt-10 space-y-4">
          <div className="w-24 h-24 bg-rose-50 rounded-[3rem] flex items-center justify-center mx-auto text-rose-300">
            <User className="w-12 h-12" />
          </div>
          <h2 className="text-3xl font-serif font-black text-slate-800 uppercase tracking-tighter">Join Luvelle</h2>
          <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest max-w-[200px] mx-auto leading-relaxed">Sign in to manage your sanctuaries and ritual history.</p>
        </div>
        <button 
          onClick={() => onNavigate('auth')}
          className="w-full py-6 bg-rose-500 text-white rounded-[2.5rem] font-black uppercase tracking-[0.2em] text-[11px] shadow-xl shadow-rose-200 active-scale"
        >
          Sign In / Sign Up
        </button>
        <div className="pt-8 space-y-4">
          <ProfileLink icon={<Info className="w-5 h-5" />} label="Our Philosophy" onClick={() => onNavigate('about')} />
          <ProfileLink icon={<Mail className="w-5 h-5" />} label="Contact Concierge" onClick={() => onNavigate('contact')} />
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-12 animate-slide-in-up">
      <div className="flex flex-col items-center space-y-5 pt-4">
        <div className="w-36 h-36 rounded-[4.5rem] bg-rose-50 p-2 border border-rose-100 shadow-xl flex items-center justify-center text-rose-400 overflow-hidden relative group">
           <LuxeImage src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300&fit=crop" className="w-full h-full rounded-[4rem]" alt="Profile" />
           <div className="absolute inset-0 bg-rose-500/10 group-hover:bg-transparent transition-all" />
        </div>
        <div className="text-center space-y-1">
          <h2 className="text-3xl font-serif font-black text-slate-800 uppercase tracking-tighter tracking-tight">Hi, {user?.name}</h2>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.3em] flex items-center justify-center gap-2">
            <Sparkles className="w-3 h-3 text-rose-400" /> Signature Member
          </p>
        </div>
      </div>

      {/* Share the Project Card */}
      <section className="px-2">
        <div 
          onClick={handleShareApp}
          className="bg-gradient-to-br from-rose-400 to-rose-600 rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl shadow-rose-200 active-scale cursor-pointer"
        >
          <div className="absolute top-[-20px] right-[-20px] w-40 h-40 bg-white/10 rounded-full blur-2xl" />
          <div className="relative z-10 space-y-4">
            <div className="flex justify-between items-start">
              <div className="space-y-1">
                <h3 className="text-xl font-serif font-black uppercase tracking-tighter">Share the Glow</h3>
                <p className="text-[10px] font-bold text-rose-50 uppercase tracking-widest opacity-80">Invite friends to their home sanctuary</p>
              </div>
              <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center border border-white/20">
                <Share2 className="w-5 h-5" />
              </div>
            </div>
            <p className="text-[12px] font-medium leading-relaxed opacity-90 max-w-[200px]">
              Gift a ritual experience. Share Luvelle with your circle and bloom together.
            </p>
            <button className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.2em] bg-white text-rose-500 px-6 py-3 rounded-full shadow-lg">
              Share Experience
            </button>
          </div>
        </div>
      </section>
      
      <div className="space-y-10">
        <section className="space-y-4">
          <p className="px-6 text-[9px] font-black text-slate-300 uppercase tracking-[0.3em]">Sanctuary Management</p>
          <div className="space-y-3">
            <ProfileLink icon={<MapPinIcon />} label="My Sanctuaries" onClick={() => onNavigate('addresses')} />
            <ProfileLink icon={<HistoryIcon />} label="Ritual History" onClick={() => onNavigate('history')} />
            <ProfileLink icon={<SettingsIcon />} label="Aura Preferences" onClick={() => onNavigate('preferences')} />
          </div>
        </section>

        <section className="space-y-4">
          <p className="px-6 text-[9px] font-black text-slate-300 uppercase tracking-[0.3em]">Information & Support</p>
          <div className="space-y-3">
            <ProfileLink icon={<Info className="w-5 h-5" />} label="Our Philosophy" onClick={() => onNavigate('about')} />
            <ProfileLink icon={<Mail className="w-5 h-5" />} label="Contact Concierge" onClick={() => onNavigate('contact')} />
          </div>
        </section>
      </div>

      <div className="pt-8 space-y-6">
        <button 
          onClick={() => { logout(); window.location.reload(); }} 
          className="w-full h-[64px] flex items-center justify-center gap-3 text-rose-400 font-black uppercase tracking-[0.4em] text-[10px] bg-white border border-rose-100 rounded-[2.2rem] shadow-sm active-scale"
        >
          <LogOut className="w-4 h-4" /> Sign Out Sanctuary
        </button>
        <div className="text-center space-y-2">
          <p className="text-[9px] text-slate-300 font-bold uppercase tracking-[0.2em]">Member since October 2024</p>
          <p className="text-[9px] text-rose-200 font-bold uppercase tracking-[0.2em]">App Version 1.2.0 Gold Edition</p>
        </div>
      </div>
    </div>
  );
};

const ProfileLink = ({ icon, label, onClick }: { icon: React.ReactNode, label: string, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className="w-full flex items-center justify-between p-6 bg-white rounded-[2.5rem] border border-rose-50 shadow-[0_15px_30px_rgba(0,0,0,0.02)] active-scale transition-all hover:border-rose-100"
  >
    <div className="flex items-center gap-5">
      <div className="w-11 h-11 rounded-[1.2rem] bg-rose-50/50 flex items-center justify-center text-rose-400 border border-rose-100/50 shadow-inner">
        {icon}
      </div>
      <span className="font-bold text-sm text-slate-700 tracking-tight">{label}</span>
    </div>
    <div className="w-8 h-8 rounded-full bg-rose-50/30 flex items-center justify-center">
      <ArrowRight className="w-4 h-4 text-rose-200" />
    </div>
  </button>
);

const MapPinIcon = () => <MapPin className="w-5 h-5" />;
const HistoryIcon = () => <History className="w-5 h-5" />;
const SettingsIcon = () => <Settings className="w-5 h-5" />;

const App: React.FC = () => (
  <AppProvider>
    <AppContent />
  </AppProvider>
);

export default App;
