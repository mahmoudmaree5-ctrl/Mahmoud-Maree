
import React, { useEffect, useState, useRef } from 'react';
// Added ShoppingBag to imports, removed unused percent
import { ArrowRight, Clock, Sparkles, Tag, ChevronRight, ShoppingBag } from 'lucide-react';
import { SERVICES, OFFERS, BLOGS } from '../constants';
import { useApp } from '../AppContext';
import { Category, Service, Offer, Blog } from '../types';
import LuxeImage from '../components/LuxeImage';

interface HomeProps {
  onNavigate: (p: string, category?: Category | 'All') => void;
  onServiceClick: (s: Service) => void;
  onBlogClick?: (b: Blog) => void;
}

const Home: React.FC<HomeProps> = ({ onNavigate, onServiceClick, onBlogClick }) => {
  const { addToCart } = useApp();
  const topServices = SERVICES.slice(0, 3);
  const discountedProducts = SERVICES.filter(s => s.originalPrice);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [offerIndex, setOfferIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setOfferIndex((prev) => (prev + 1) % OFFERS.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const ritualCategories: { id: Category, label: string, img: string }[] = [
    { id: 'Hair', label: 'Hair Care', img: 'https://images.unsplash.com/photo-1522337363553-5605d9308ee7?w=300&fit=crop' },
    { id: 'Nails', label: 'Nails Ritual', img: 'https://images.unsplash.com/photo-1604654894610-df63bc536371?w=300&fit=crop' },
    { id: 'Massage', label: 'Body Massage', img: 'https://images.unsplash.com/photo-1544161515-4af6b1d46af0?w=300&fit=crop' },
    { id: 'Packages', label: 'Luxe Bundles', img: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=300&fit=crop' },
  ];

  return (
    <div className="animate-fade-in space-y-10 pb-16">
      {/* Hero Header */}
      <section className="px-6 pt-4">
        <div className="relative h-72 bg-rose-200 rounded-[3.5rem] p-10 text-white flex flex-col justify-center overflow-hidden shadow-[0_25px_60px_-15px_rgba(244,114,182,0.3)]">
           <LuxeImage 
             src="https://images.unsplash.com/photo-1596178065887-1198b6174551?w=800&fit=crop" 
             className="absolute inset-0 w-full h-full opacity-60 scale-105" 
             alt="Luvelle Hero" 
           />
           <div className="absolute inset-0 bg-gradient-to-br from-rose-500/80 via-rose-500/40 to-transparent" />
           
           <div className="relative z-10 space-y-3">
              <div className="bg-white/20 backdrop-blur-md w-fit px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] mb-2 border border-white/20">
                Luxe On-Demand
              </div>
              <h2 className="text-4xl font-serif font-black tracking-tighter uppercase leading-[0.9]">Rituals <br /> At Home</h2>
              <p className="text-[12px] font-medium text-rose-50 leading-relaxed max-w-[180px] opacity-90">Premium beauty services delivered to your sanctuary.</p>
              
              <button 
                onClick={() => onNavigate('services')}
                className="mt-6 w-fit h-[52px] px-8 bg-white text-rose-500 rounded-[1.8rem] font-black text-[11px] uppercase tracking-widest active-scale shadow-xl flex items-center justify-center"
              >
                Book Ritual
              </button>
           </div>
        </div>
      </section>

      {/* Main Promotions Slider */}
      <section className="space-y-5">
        <div className="px-6 flex justify-between items-end">
          <div className="space-y-1">
            <h3 className="text-2xl font-serif font-black text-slate-800 tracking-tighter uppercase">Seasonal Joys</h3>
            <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">Limited edition promotions</p>
          </div>
        </div>
        <div className="relative overflow-hidden">
          <div 
            className="flex transition-transform duration-700 ease-in-out"
            style={{ transform: `translateX(-${offerIndex * 100}%)` }}
          >
            {OFFERS.map((offer) => (
              <div key={offer.id} className="w-full flex-shrink-0 px-6">
                <div 
                  onClick={() => onNavigate('offers')}
                  className="relative h-44 rounded-[3rem] overflow-hidden group active-scale shadow-xl shadow-rose-100/50 border border-rose-50"
                >
                  <LuxeImage src={offer.image} className="w-full h-full" alt={offer.title} />
                  <div className="absolute inset-0 bg-gradient-to-r from-rose-900/60 via-rose-900/20 to-transparent" />
                  <div className="absolute inset-0 p-8 flex flex-col justify-center text-white">
                    <div className="flex items-center gap-2 mb-2">
                      <Tag className="w-4 h-4 text-rose-300" />
                      <span className="text-[9px] font-black uppercase tracking-widest">{offer.discount} Off</span>
                    </div>
                    <h4 className="text-xl font-serif font-black uppercase tracking-tight">{offer.title}</h4>
                    <p className="text-[10px] font-medium opacity-80 mt-1 max-w-[200px]">{offer.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="flex justify-center gap-2 mt-4">
            {OFFERS.map((_, i) => (
              <div 
                key={i} 
                className={`h-1 rounded-full transition-all duration-300 ${i === offerIndex ? 'w-6 bg-rose-500' : 'w-2 bg-rose-100'}`} 
              />
            ))}
          </div>
        </div>
      </section>

      {/* Ritual Product Offers Slider */}
      <section className="space-y-5">
        <div className="px-6 flex justify-between items-end">
          <div className="space-y-1">
            <h3 className="text-2xl font-serif font-black text-slate-800 tracking-tighter uppercase">Ritual Offers</h3>
            <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">Discounted sanctuary services</p>
          </div>
          <button 
            onClick={() => onNavigate('offers')}
            className="h-10 px-4 flex items-center gap-1.5 text-rose-400 text-[10px] font-black uppercase tracking-widest"
          >
            See All <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="flex gap-6 overflow-x-auto no-scrollbar py-2 -mx-6 px-6">
          {discountedProducts.map((service) => (
            <div 
              key={service.id} 
              onClick={() => onServiceClick(service)}
              className="flex-shrink-0 w-64 bg-white rounded-[3rem] overflow-hidden border border-rose-50 shadow-lg active-scale group cursor-pointer"
            >
              <div className="h-40 relative">
                <LuxeImage src={service.image} className="w-full h-full" alt={service.name} />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1.5 bg-rose-500 text-white rounded-full text-[8px] font-black uppercase tracking-widest shadow-lg">
                    -{Math.round(((service.originalPrice! - service.price) / service.originalPrice!) * 100)}% Off
                  </span>
                </div>
                <button 
                   onClick={(e) => { e.stopPropagation(); addToCart(service); }}
                   className="absolute bottom-4 right-4 w-10 h-10 bg-white/90 backdrop-blur-md rounded-2xl flex items-center justify-center text-rose-500 shadow-lg active:scale-90 transition-transform"
                >
                  <ShoppingBag className="w-4 h-4" />
                </button>
              </div>
              <div className="p-6 space-y-2">
                <h4 className="font-bold text-slate-800 text-sm line-clamp-1">{service.name}</h4>
                <div className="flex items-center gap-2">
                  <span className="text-rose-600 font-black text-lg">${service.price}</span>
                  <span className="text-slate-300 text-xs line-through font-bold">${service.originalPrice}</span>
                </div>
                <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-bold uppercase tracking-tighter">
                  <Clock className="w-3.5 h-3.5 text-rose-200" /> {service.duration}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Ritual Categories */}
      <section className="px-6 space-y-6">
        <div className="space-y-1">
          <h3 className="text-2xl font-serif font-black text-slate-800 tracking-tighter uppercase">Ritual Types</h3>
          <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">Select your escape</p>
        </div>
        <div className="flex gap-5 overflow-x-auto no-scrollbar py-2 -mx-6 px-6">
          {ritualCategories.map((cat) => (
            <button 
              key={cat.id}
              onClick={() => onNavigate('services', cat.id)}
              className="flex-shrink-0 w-36 group space-y-4"
            >
              <div className="relative aspect-[3/4] rounded-[2.8rem] overflow-hidden shadow-lg group-active:scale-95 transition-all">
                <LuxeImage src={cat.img} className="w-full h-full transition-transform duration-700 group-hover:scale-110" alt={cat.label} />
                <div className="absolute inset-0 bg-gradient-to-t from-rose-900/40 to-transparent" />
              </div>
              <span className="block text-[11px] font-black text-slate-500 uppercase tracking-widest text-center">{cat.label}</span>
            </button>
          ))}
        </div>
      </section>

      {/* News Slider */}
      <section className="space-y-5">
        <div className="px-6 flex justify-between items-end">
          <div className="space-y-1">
            <h3 className="text-2xl font-serif font-black text-slate-800 tracking-tighter uppercase">The Journal</h3>
            <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">Editorial Wellness</p>
          </div>
          <button 
            onClick={() => onNavigate('news')}
            className="h-10 px-4 flex items-center gap-1.5 text-rose-400 text-[10px] font-black uppercase tracking-widest"
          >
            Read All <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="flex gap-6 overflow-x-auto no-scrollbar py-2 -mx-6 px-6">
          {BLOGS.map((blog) => (
            <button 
              key={blog.id} 
              onClick={() => onBlogClick?.(blog)}
              className="flex-shrink-0 w-72 bg-white rounded-[3rem] overflow-hidden border border-rose-50 shadow-lg active-scale group text-left"
            >
              <div className="h-40 relative">
                <LuxeImage src={blog.image} className="w-full h-full" alt={blog.title} />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1.5 bg-white/90 backdrop-blur-md rounded-full text-[8px] font-black text-rose-500 uppercase tracking-widest">Journal</span>
                </div>
              </div>
              <div className="p-6 space-y-2">
                <h4 className="font-bold text-slate-800 text-sm line-clamp-1">{blog.title}</h4>
                <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed font-medium">{blog.excerpt}</p>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Featured Service */}
      <section className="px-6 space-y-8">
        <div className="flex justify-between items-end">
          <div className="space-y-1">
            <h3 className="text-2xl font-serif font-black text-slate-800 tracking-tighter uppercase">Trending</h3>
            <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">Most loved rituals</p>
          </div>
          <button 
            onClick={() => onNavigate('services')}
            className="text-rose-400 text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 h-[44px] px-4"
          >
            All <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-6">
          {topServices.map(service => (
            <div 
              key={service.id} 
              onClick={() => onServiceClick(service)}
              className="flex gap-6 bg-white p-6 rounded-[3rem] border border-rose-50 shadow-[0_15px_45px_-15px_rgba(0,0,0,0.05)] active-scale relative overflow-hidden group cursor-pointer"
            >
              <div className="w-28 h-28 rounded-[2.2rem] overflow-hidden shadow-inner flex-shrink-0">
                <LuxeImage src={service.image} className="w-full h-full transition-transform duration-1000 group-hover:scale-110" alt={service.name} />
              </div>
              <div className="flex-1 flex flex-col justify-between py-1">
                <div>
                  <div className="text-[10px] font-black text-rose-400 uppercase tracking-widest mb-1">{service.category}</div>
                  <h4 className="font-bold text-slate-800 text-base leading-tight">{service.name}</h4>
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-bold uppercase mt-1">
                    <Clock className="w-3.5 h-3.5 text-rose-300" /> {service.duration}
                  </div>
                </div>
                <div className="flex justify-between items-center mt-3">
                  <span className="font-black text-rose-500 text-xl">${service.price}</span>
                  <button 
                    onClick={(e) => { e.stopPropagation(); addToCart(service); }}
                    className="w-[48px] h-[48px] bg-gradient-to-br from-rose-400 to-rose-500 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-rose-200 active:scale-90 transition-transform"
                  >
                    <Sparkles className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;
