
import React, { useState } from 'react';
import { Calendar as CalIcon, Clock, MapPin, CheckCircle2, ChevronRight, ChevronLeft } from 'lucide-react';

const Booking: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [selectedDate, setSelectedDate] = useState<number | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);

  const dates = [
    { day: 'Mon', num: 24 }, { day: 'Tue', num: 25 }, { day: 'Wed', num: 26 },
    { day: 'Thu', num: 27 }, { day: 'Fri', num: 28 }, { day: 'Sat', num: 29 }
  ];

  const times = ['09:00 AM', '10:30 AM', '01:00 PM', '02:30 PM', '04:00 PM', '06:30 PM'];

  if (step === 3) {
    return (
      <div className="container mx-auto px-8 py-24 text-center space-y-10 animate-fade-in max-w-md">
        <div className="w-32 h-32 bg-white rounded-[4rem] flex items-center justify-center mx-auto shadow-2xl border border-rose-50">
          <CheckCircle2 className="w-16 h-16 text-green-400" />
        </div>
        <div className="space-y-3">
          <h1 className="text-4xl font-serif font-black text-slate-800 tracking-tighter uppercase">Ritual Confirmed</h1>
          <p className="text-sm text-slate-400 font-medium leading-relaxed max-w-[240px] mx-auto">Your beauty artisan is preparing for your home sanctuary.</p>
        </div>
        <button 
          onClick={onComplete}
          className="w-full py-6 bg-rose-500 text-white rounded-[2.2rem] font-black uppercase tracking-[0.2em] text-[11px] shadow-2xl shadow-rose-200"
        >
          Return Home
        </button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-6 py-8 animate-fade-in pb-24 max-w-lg">
      <div className="mb-10 flex items-end justify-between">
        <div className="space-y-1">
          <h1 className="text-3xl font-serif font-black text-slate-800 tracking-tighter uppercase">Schedule Ritual</h1>
          <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">Select your time</p>
        </div>
        <div className="text-[9px] font-black text-rose-500 uppercase tracking-[0.2em] bg-rose-50 px-4 py-2 rounded-full border border-rose-100">Step {step} of 2</div>
      </div>

      <div className="bg-white rounded-[4rem] shadow-2xl shadow-rose-100/50 border border-rose-100/30 overflow-hidden">
        {step === 1 ? (
          <div className="p-10 space-y-10">
            <div className="space-y-5">
              <div className="flex justify-between items-center ml-2 mr-2">
                <h3 className="font-black text-slate-800 text-[10px] uppercase tracking-[0.25em]">Select Date</h3>
                <div className="flex gap-3">
                  <button className="p-2 rounded-xl bg-rose-50 text-rose-300"><ChevronLeft className="w-4 h-4" /></button>
                  <button className="p-2 rounded-xl bg-rose-50 text-rose-300"><ChevronRight className="w-4 h-4" /></button>
                </div>
              </div>
              <div className="flex justify-between gap-2 overflow-x-auto no-scrollbar py-1">
                {dates.map((d) => (
                  <button 
                    key={d.num}
                    onClick={() => setSelectedDate(d.num)}
                    className={`flex flex-col items-center gap-3 p-4 rounded-[1.8rem] min-w-[64px] transition-all border ${
                      selectedDate === d.num 
                        ? 'bg-rose-500 text-white border-rose-500 shadow-xl shadow-rose-200 -translate-y-2' 
                        : 'bg-white text-slate-400 border-rose-50 hover:bg-rose-50/50 active:scale-95'
                    }`}
                  >
                    <span className="text-[9px] font-black uppercase tracking-widest">{d.day}</span>
                    <span className="text-base font-black">{d.num}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-5">
              <h3 className="font-black text-slate-800 text-[10px] uppercase tracking-[0.25em] ml-2">Available Hours</h3>
              <div className="grid grid-cols-2 gap-4">
                {times.map((t) => (
                  <button 
                    key={t}
                    onClick={() => setSelectedTime(t)}
                    className={`py-4.5 rounded-[1.5rem] text-[11px] font-black uppercase tracking-widest transition-all border ${
                      selectedTime === t 
                        ? 'bg-rose-500 text-white border-rose-500 shadow-xl shadow-rose-100' 
                        : 'bg-white text-slate-500 border-rose-50 hover:bg-rose-50'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            <button 
              disabled={!selectedDate || !selectedTime}
              onClick={() => setStep(2)}
              className="w-full py-6 bg-gradient-to-r from-rose-400 to-rose-600 text-white rounded-[2.2rem] font-black uppercase tracking-[0.2em] text-[11px] shadow-2xl shadow-rose-200 disabled:opacity-30 disabled:shadow-none transition-all active:scale-95 mt-4"
            >
              Confirm Sanctuary Slot
            </button>
          </div>
        ) : (
          <div className="p-10 space-y-10">
            <h3 className="font-black text-slate-800 text-[10px] uppercase tracking-[0.25em] ml-2">Sanctuary Address</h3>
            <div className="space-y-4">
              <div className="p-6 bg-white rounded-[2.2rem] border-2 border-rose-500 flex items-start gap-4 shadow-xl shadow-rose-50">
                <div className="w-12 h-12 bg-rose-50 rounded-2xl flex items-center justify-center text-rose-500 shadow-sm flex-shrink-0"><MapPin className="w-6 h-6" /></div>
                <div className="pt-1">
                  <div className="font-black text-slate-800 text-sm tracking-tight">Main Sanctuary</div>
                  <p className="text-[11px] text-slate-400 font-medium leading-relaxed mt-1">123 Rose Avenue, Beverly Hills, CA 90210</p>
                </div>
              </div>
              <button className="w-full p-5 border-2 border-dashed border-rose-100 rounded-[2rem] text-rose-300 font-black text-[10px] uppercase tracking-widest">+ Add New Sanctuary</button>
            </div>

            <div className="bg-rose-50/20 p-8 rounded-[2.5rem] space-y-5 border border-rose-50">
               <h4 className="font-black text-rose-400 text-[10px] uppercase tracking-[0.3em] mb-4">Summary</h4>
               <div className="flex justify-between items-center text-[11px] font-bold uppercase tracking-widest">
                 <span className="text-slate-300">Sanctuary Date</span>
                 <span className="text-slate-700">Oct {selectedDate}, 2024</span>
               </div>
               <div className="flex justify-between items-center text-[11px] font-bold uppercase tracking-widest pt-2">
                 <span className="text-slate-300">Sanctuary Time</span>
                 <span className="text-slate-700">{selectedTime}</span>
               </div>
            </div>

            <div className="flex gap-4">
              <button onClick={() => setStep(1)} className="flex-1 py-5 bg-white border border-rose-100 text-slate-400 rounded-[2rem] font-bold text-[10px] uppercase tracking-widest">Back</button>
              <button 
                onClick={() => setStep(3)}
                className="flex-[2] py-6 bg-gradient-to-r from-rose-400 to-rose-600 text-white rounded-[2rem] font-black uppercase tracking-[0.2em] text-[11px] shadow-2xl shadow-rose-200 active:scale-95 transition-all"
              >
                Confirm Ritual
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Booking;
