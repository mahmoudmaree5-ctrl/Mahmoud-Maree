
import React, { useState } from 'react';
import { useApp } from '../AppContext';
import { Mail, Lock, User, Sparkles } from 'lucide-react';

const Auth: React.FC<{ onNavigate: (p: string) => void }> = ({ onNavigate }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const { login } = useApp();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login(email || 'guest@luvelle.com');
  };

  return (
    <div className="container mx-auto px-6 py-10 animate-fade-in max-w-lg">
      <div className="bg-white rounded-[4rem] shadow-2xl shadow-rose-100 p-12 border border-rose-50 space-y-12 relative overflow-hidden">
        <div className="absolute top-[-50px] right-[-50px] w-64 h-64 bg-rose-50 rounded-full blur-3xl opacity-60" />
        
        <div className="text-center space-y-3 relative z-10">
          <h2 className="text-5xl font-serif font-black text-slate-800 tracking-tighter uppercase">
            {isLogin ? 'Welcome' : 'Join Us'}
          </h2>
          <p className="text-[11px] text-slate-400 font-bold uppercase tracking-[0.3em]">
            {isLogin ? 'Enter your sanctuary' : 'Start your beauty story'}
          </p>
        </div>

        <form className="space-y-8" onSubmit={handleSubmit}>
          {!isLogin && (
            <div className="space-y-2.5">
              <label className="text-[10px] font-black text-rose-300 uppercase tracking-[0.2em] ml-4">Sanctuary Name</label>
              <div className="relative group">
                <User className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-rose-200 group-focus-within:text-rose-500 transition-colors" />
                <input type="text" className="w-full bg-rose-50/30 border border-rose-100 rounded-[2rem] pl-16 pr-6 py-5 text-sm font-medium focus:ring-4 focus:ring-rose-50/50 outline-none transition-all placeholder:text-rose-200" placeholder="Jane Doe" required />
              </div>
            </div>
          )}
          <div className="space-y-2.5">
            <label className="text-[10px] font-black text-rose-300 uppercase tracking-[0.2em] ml-4">Email Address</label>
            <div className="relative group">
              <Mail className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-rose-200 group-focus-within:text-rose-500 transition-colors" />
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-rose-50/30 border border-rose-100 rounded-[2rem] pl-16 pr-6 py-5 text-sm font-medium focus:ring-4 focus:ring-rose-50/50 outline-none transition-all placeholder:text-rose-200" 
                placeholder="jane@example.com" 
                required 
              />
            </div>
          </div>
          <div className="space-y-2.5">
            <div className="flex justify-between items-center ml-4 mr-4">
              <label className="text-[10px] font-black text-rose-300 uppercase tracking-[0.2em]">Password</label>
              {isLogin && <button type="button" className="text-[9px] text-rose-400 font-black uppercase tracking-widest">Forgot?</button>}
            </div>
            <div className="relative group">
              <Lock className="absolute left-6 top-1/2 -translate-y-1/2 w-4 h-4 text-rose-200 group-focus-within:text-rose-500 transition-colors" />
              <input type="password"  className="w-full bg-rose-50/30 border border-rose-100 rounded-[2rem] pl-16 pr-6 py-5 text-sm font-medium focus:ring-4 focus:ring-rose-50/50 outline-none transition-all placeholder:text-rose-200" placeholder="••••••••" required />
            </div>
          </div>

          <button className="w-full py-6 bg-gradient-to-r from-rose-400 to-rose-600 text-white rounded-[2.5rem] font-black uppercase tracking-[0.25em] text-[11px] shadow-[0_20px_40px_-10px_rgba(244,114,182,0.5)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3 mt-10">
            {isLogin ? 'Enter Sanctuary' : 'Create Rituals'} <Sparkles className="w-4 h-4" />
          </button>
        </form>

        <div className="text-center pt-4">
          <p className="text-[11px] font-bold text-slate-300 uppercase tracking-widest">
            {isLogin ? "No Sanctuary?" : "Already Member?"}
            <button 
              onClick={() => setIsLogin(!isLogin)}
              className="ml-3 text-rose-500 font-black"
            >
              {isLogin ? 'Sign Up' : 'Login'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Auth;
