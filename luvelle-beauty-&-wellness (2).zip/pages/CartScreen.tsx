
import React, { useState } from 'react';
import { Minus, Plus, Trash2, Calendar, ShoppingBag, MessageCircle, Ticket, X } from 'lucide-react';
import { useApp } from '../AppContext';
import { getWhatsAppLink } from '../utils/whatsapp';

const CartScreen: React.FC<{ onCheckout: () => void }> = ({ onCheckout }) => {
  const { cart, updateQuantity, removeFromCart } = useApp();
  const [coupon, setCoupon] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState(0);
  const [couponError, setCouponError] = useState('');

  const total = cart.reduce((acc, curr) => acc + (curr.price * curr.quantity), 0);
  const conciergeFee = 10;

  const handleApplyCoupon = () => {
    if (coupon.toUpperCase() === 'WELCOME20') {
      setAppliedDiscount(Math.floor(total * 0.2));
      setCouponError('');
    } else if (coupon.toUpperCase() === 'BUNDLELUXE') {
      setAppliedDiscount(Math.floor(total * 0.15));
      setCouponError('');
    } else {
      setCouponError('Invalid coupon code');
      setAppliedDiscount(0);
    }
  };

  const removeCoupon = () => {
    setCoupon('');
    setAppliedDiscount(0);
  };

  if (cart.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[75vh] p-10 space-y-8 animate-fade-in">
        <div className="w-32 h-32 bg-rose-50 rounded-[3.5rem] flex items-center justify-center border border-rose-100 shadow-inner">
          <ShoppingBag className="w-14 h-14 text-rose-200" />
        </div>
        <div className="text-center space-y-3">
          <h3 className="text-3xl font-serif font-black text-slate-800 uppercase tracking-tighter">Bag is Empty</h3>
          <p className="text-[12px] text-slate-400 font-bold uppercase tracking-widest">A clean slate for your sanctuary</p>
        </div>
        <button 
          onClick={() => window.location.reload()}
          className="w-full max-w-[280px] h-[60px] bg-rose-500 text-white rounded-[2rem] font-black text-[11px] uppercase tracking-widest shadow-2xl shadow-rose-200"
        >
          Explore Rituals
        </button>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-12 animate-slide-in-up pb-40">
      <div className="space-y-1">
        <h2 className="text-3xl font-serif font-black text-slate-800 tracking-tighter uppercase">Your Bag</h2>
        <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">Sanctuary Preparation</p>
      </div>
      
      <div className="space-y-6">
        {cart.map((item) => (
          <div key={item.id} className="flex gap-6 p-6 bg-white rounded-[3.2rem] border border-rose-50 shadow-[0_15px_45px_-15px_rgba(0,0,0,0.03)] group">
            <div className="w-24 h-24 rounded-[2rem] overflow-hidden bg-slate-100 flex-shrink-0 shadow-sm border border-rose-50">
              <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 flex flex-col justify-between py-1">
              <div className="flex justify-between items-start">
                <div className="space-y-1">
                  <h4 className="font-bold text-slate-800 text-[16px] leading-tight">{item.name}</h4>
                  <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">{item.duration}</p>
                </div>
                <button 
                  onClick={() => removeFromCart(item.id)} 
                  className="w-[40px] h-[40px] flex items-center justify-center text-slate-200 hover:text-red-400 transition-colors bg-slate-50/50 rounded-xl"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
              <div className="flex justify-between items-center mt-4">
                <div className="flex items-center bg-rose-50 rounded-2xl p-1.5 border border-rose-100">
                  <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="w-8 h-8 flex items-center justify-center text-rose-400 active:scale-90"><Minus className="w-4 h-4" /></button>
                  <span className="mx-5 text-sm font-black text-rose-600">{item.quantity}</span>
                  <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="w-8 h-8 flex items-center justify-center text-rose-400 active:scale-90"><Plus className="w-4 h-4" /></button>
                </div>
                <span className="font-black text-rose-600 text-xl">${item.price * item.quantity}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Coupon Field */}
      <div className="bg-white p-8 rounded-[2.8rem] border border-rose-50 shadow-sm space-y-4">
        <div className="flex items-center gap-2 mb-2">
          <Ticket className="w-4 h-4 text-rose-300" />
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Apply Promo Code</span>
        </div>
        {appliedDiscount > 0 ? (
          <div className="flex items-center justify-between bg-rose-50 p-4 rounded-2xl border border-rose-100">
            <span className="text-[11px] font-black text-rose-600 uppercase tracking-widest">Code Applied: {coupon.toUpperCase()}</span>
            <button onClick={removeCoupon} className="p-1 text-rose-400"><X className="w-4 h-4" /></button>
          </div>
        ) : (
          <div className="flex gap-2">
            <input 
              type="text" 
              value={coupon}
              onChange={(e) => setCoupon(e.target.value)}
              placeholder="e.g. WELCOME20"
              className="flex-1 h-[52px] px-6 bg-rose-50/30 rounded-2xl border border-rose-100 text-sm font-bold placeholder:text-rose-200 outline-none focus:ring-4 focus:ring-rose-50"
            />
            <button 
              onClick={handleApplyCoupon}
              className="px-6 h-[52px] bg-rose-100 text-rose-500 rounded-2xl font-black text-[10px] uppercase tracking-widest active-scale"
            >
              Apply
            </button>
          </div>
        )}
        {couponError && <p className="text-[10px] text-red-400 font-bold uppercase tracking-widest ml-4">{couponError}</p>}
      </div>

      <div className="bg-white p-10 rounded-[3.8rem] shadow-2xl shadow-rose-100/50 border border-rose-100/50 space-y-8">
        <div className="space-y-4">
          <div className="flex justify-between items-center text-[12px] font-black uppercase tracking-widest text-slate-300">
            <span>Bag Total</span>
            <span className="text-slate-800">${total}</span>
          </div>
          <div className="flex justify-between items-center text-[12px] font-black uppercase tracking-widest text-slate-300">
            <span>Concierge Fee</span>
            <span className="text-slate-800">${conciergeFee}</span>
          </div>
          {appliedDiscount > 0 && (
            <div className="flex justify-between items-center text-[12px] font-black uppercase tracking-widest text-rose-400">
              <span>Promo Discount</span>
              <span>-${appliedDiscount}</span>
            </div>
          )}
          <div className="flex justify-between items-center pt-4 border-t border-rose-50">
            <span className="text-3xl font-serif font-black text-slate-800 uppercase tracking-tighter">Total</span>
            <span className="text-3xl font-black text-rose-500">${total + conciergeFee - appliedDiscount}</span>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <button 
            onClick={onCheckout}
            className="w-full h-[64px] bg-gradient-to-r from-rose-400 to-rose-600 text-white rounded-[2.2rem] font-black uppercase tracking-[0.2em] text-[11px] flex items-center justify-center gap-3 shadow-2xl shadow-rose-300 active-scale"
          >
            <Calendar className="w-5 h-5" />
            Schedule Sanctuary
          </button>
          
          <a 
            href={getWhatsAppLink(cart)}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full h-[64px] bg-white border border-[#25D366]/30 text-[#25D366] rounded-[2.2rem] text-[11px] font-black uppercase tracking-[0.2em] flex items-center justify-center gap-3 active-scale"
          >
            <MessageCircle className="w-5 h-5" />
            Book via WhatsApp
          </a>
        </div>
      </div>
    </div>
  );
};

export default CartScreen;
