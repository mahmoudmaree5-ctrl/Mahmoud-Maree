
import React, { useState, useEffect } from 'react';
import { Search } from 'lucide-react';
import { SERVICES } from '../constants';
import { useApp } from '../AppContext';
import { Category, Service } from '../types';
import ServiceCard from '../components/ServiceCard';
import { getWhatsAppLink } from '../utils/whatsapp';

interface ServicesProps {
  initialCategory: Category | 'All';
  onServiceClick: (s: Service) => void;
}

const Services: React.FC<ServicesProps> = ({ initialCategory, onServiceClick }) => {
  const { addToCart } = useApp();
  const [activeCategory, setActiveCategory] = useState<Category | 'All'>(initialCategory);
  const [search, setSearch] = useState('');

  const categories: (Category | 'All')[] = ['All', 'Hair', 'Nails', 'Massage', 'Packages', 'Skin'];

  useEffect(() => {
    setActiveCategory(initialCategory);
  }, [initialCategory]);

  const filteredServices = SERVICES.filter(s => 
    (activeCategory === 'All' || s.category === activeCategory) &&
    (s.name.toLowerCase().includes(search.toLowerCase()) || s.category.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="container mx-auto pb-24">
      {/* Search & Sticky Categories */}
      <div className="sticky top-[env(safe-area-inset-top,60px)] z-30 bg-[#FFFBFD]/95 backdrop-blur-xl pt-4 pb-6 px-6 border-b border-rose-50/50">
        <div className="space-y-6">
          <div className="relative group">
            <div className="absolute inset-y-0 left-5 flex items-center pointer-events-none">
              <Search className="w-5 h-5 text-rose-300" />
            </div>
            <input 
              type="text" 
              placeholder="Search rituals..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full h-[56px] bg-white border border-rose-100 rounded-[2.2rem] pl-14 pr-6 py-4.5 text-sm text-slate-700 outline-none transition-all shadow-sm focus:ring-4 focus:ring-rose-50"
            />
          </div>
          
          <div className="flex overflow-x-auto gap-3 scrollbar-hide py-1 -mx-6 px-6 no-scrollbar">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-7 h-[44px] rounded-[1.6rem] text-[10px] font-black uppercase tracking-widest whitespace-nowrap transition-all border ${
                  activeCategory === cat 
                    ? 'bg-rose-500 text-white border-rose-500 shadow-xl shadow-rose-200 scale-105' 
                    : 'bg-white text-slate-400 border-rose-100'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Services Grid */}
      <div className="px-6 pt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 lg:gap-12 animate-fade-in">
        {filteredServices.length > 0 ? (
          filteredServices.map(service => (
            <ServiceCard 
              key={service.id}
              service={service}
              onClick={() => onServiceClick(service)}
              onAddToCart={(e) => {
                e.stopPropagation();
                addToCart(service);
              }}
              onWhatsAppClick={(e) => {
                e.stopPropagation();
                window.open(getWhatsAppLink([{ ...service, quantity: 1 }]), '_blank');
              }}
            />
          ))
        ) : (
          <div className="col-span-full py-32 text-center space-y-6">
            <div className="w-24 h-24 bg-rose-50 rounded-[3.5rem] flex items-center justify-center mx-auto border border-rose-100 shadow-inner">
              <Search className="w-10 h-10 text-rose-200" />
            </div>
            <div className="space-y-2">
              <h3 className="text-2xl font-serif font-black text-slate-800 uppercase tracking-tighter">No Rituals Found</h3>
              <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">Try another category</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Services;
