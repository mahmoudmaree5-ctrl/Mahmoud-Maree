
import React from 'react';
import { BLOGS } from '../constants';
import { Clock, User, ArrowRight } from 'lucide-react';
import { Blog } from '../types';

interface NewsProps {
  onBlogClick: (blog: Blog) => void;
}

const News: React.FC<NewsProps> = ({ onBlogClick }) => {
  return (
    <div className="container mx-auto px-5 py-8 animate-fade-in pb-24 max-w-lg lg:max-w-4xl">
      <div className="mb-10 text-center space-y-2">
        <h1 className="text-3xl md:text-5xl font-serif font-bold text-slate-800 uppercase tracking-tighter">The Beauty Journal</h1>
        <p className="text-xs text-slate-400 font-medium uppercase tracking-widest">Stories, Trends & Wellness Tips</p>
      </div>

      <div className="space-y-8">
        {BLOGS.map((blog) => (
          <div 
            key={blog.id} 
            onClick={() => onBlogClick(blog)}
            className="bg-white rounded-[2.5rem] overflow-hidden shadow-xl shadow-rose-100/50 border border-rose-50 group cursor-pointer active-scale"
          >
            <div className="relative h-64 md:h-80 overflow-hidden">
              <img src={blog.image} alt={blog.title} className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" />
              <div className="absolute top-6 left-6">
                <span className="bg-white/90 backdrop-blur-md px-4 py-2 rounded-full text-[9px] font-black text-rose-500 uppercase tracking-[0.2em] shadow-sm">Editorial</span>
              </div>
            </div>
            <div className="p-8 space-y-4">
              <div className="flex items-center gap-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                <span className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5 text-rose-300" /> {blog.date}</span>
                <span className="flex items-center gap-1.5"><User className="w-3.5 h-3.5 text-rose-300" /> {blog.author}</span>
              </div>
              <h2 className="text-2xl font-serif font-bold text-slate-800 leading-tight group-hover:text-rose-500 transition-colors">{blog.title}</h2>
              <p className="text-sm text-slate-500 leading-relaxed line-clamp-3 font-medium">{blog.excerpt}</p>
              <button className="pt-4 flex items-center gap-2 text-rose-500 text-xs font-black uppercase tracking-widest group/btn">
                Read Ritual <ArrowRight className="w-4 h-4 transition-transform group-hover/btn:translate-x-1" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default News;
