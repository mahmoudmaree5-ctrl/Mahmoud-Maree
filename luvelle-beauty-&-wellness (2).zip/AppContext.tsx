
import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem, Service, Address, User } from './types';

interface AppContextType {
  cart: CartItem[];
  addToCart: (service: Service) => void;
  removeFromCart: (serviceId: string) => void;
  updateQuantity: (serviceId: string, quantity: number) => void;
  clearCart: () => void;
  addresses: Address[];
  addAddress: (address: Omit<Address, 'id'>) => void;
  removeAddress: (id: string) => void;
  user: User | null;
  login: (email: string) => void;
  logout: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [addresses, setAddresses] = useState<Address[]>([
    { id: '1', label: 'Home Sanctuary', street: '123 Rose Avenue', city: 'Beverly Hills', isDefault: true }
  ]);
  const [user, setUser] = useState<User | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Initialize with dummy user for demo if needed, but let's keep it clean
  useEffect(() => {
    // Optional: Load cart from localStorage for persistence
    const saved = localStorage.getItem('luvelle_cart');
    if (saved) setCart(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('luvelle_cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = (service: Service) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === service.id);
      if (existing) {
        return prev.map(item => item.id === service.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...service, quantity: 1 }];
    });
    // Visual feedback handled by UI components
  };

  const removeFromCart = (serviceId: string) => {
    setCart(prev => prev.filter(item => item.id !== serviceId));
  };

  const updateQuantity = (serviceId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(serviceId);
      return;
    }
    setCart(prev => prev.map(item => item.id === serviceId ? { ...item, quantity } : item));
  };

  const clearCart = () => setCart([]);

  const addAddress = (address: Omit<Address, 'id'>) => {
    const newAddress = { ...address, id: Math.random().toString(36).substr(2, 9) };
    setAddresses(prev => [...prev, newAddress]);
  };

  const removeAddress = (id: string) => {
    setAddresses(prev => prev.filter(a => a.id !== id));
  };

  const login = (email: string) => {
    setUser({ 
      id: 'u1', 
      name: email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1), 
      email 
    });
  };

  const logout = () => setUser(null);

  return (
    <AppContext.Provider value={{
      cart, addToCart, removeFromCart, updateQuantity, clearCart,
      addresses, addAddress, removeAddress,
      user, login, logout,
      isCartOpen, setIsCartOpen
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
