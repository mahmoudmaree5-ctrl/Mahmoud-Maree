
import React from 'react';
import { Menu, ShoppingBag } from 'lucide-react';
import { useApp } from '../AppContext';

interface HeaderBarProps {
  title: string;
  onOpenDrawer: () => void;
  onNavigateToCart: () => void;
}

const HeaderBar: React.FC<HeaderBarProps> = ({ title, onOpenDrawer, onNavigateToCart }) => {
  const { cart } = useApp();
  const cartCount = cart.reduce((acc, curr) => acc + curr.quantity, 0);

  const displayTitle = title === 'home' ? 'LUVELLE' : title.charAt(0).toUpperCase() + title.slice(1);

  return (
    <div className="sticky top-0 z-40 w-full bg-white/60 backdrop-blur-2xl px-6 py-4 flex items-center justify-between border-b border-rose-100/30 pt-[env(safe-area-inset-top,20px)] shadow-sm">
      <button 
        onClick={onOpenDrawer}
        className="p-2.5 bg-white rounded-[1.2rem] shadow-sm text-slate-700 hover:bg-rose-50 transition-all active:scale-90"
      >
        <Menu className="w-5 h-5" />
      </button>
      
      <h1 className="text-xl font-serif font-black text-rose-400 tracking-tighter uppercase drop-shadow-sm">
        {displayTitle}
      </h1>

      <button 
        onClick={onNavigateToCart}
        className="relative p-2.5 bg-white rounded-[1.2rem] shadow-sm text-slate-700 hover:bg-rose-50 transition-all active:scale-90"
      >
        <ShoppingBag className="w-5 h-5" />
        {cartCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-gradient-to-br from-rose-400 to-rose-600 text-white text-[9px] font-black w-5 h-5 flex items-center justify-center rounded-full border-2 border-white shadow-lg">
            {cartCount}
          </span>
        )}
      </button>
    </div>
  );
};

export default HeaderBar;
