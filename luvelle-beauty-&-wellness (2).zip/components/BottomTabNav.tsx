
import React from 'react';
import { Home, Sparkles, ShoppingBag, Calendar, User } from 'lucide-react';
import { useApp } from '../AppContext';

interface BottomTabNavProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

const BottomTabNav: React.FC<BottomTabNavProps> = ({ onNavigate, currentPage }) => {
  const { cart } = useApp();
  const cartCount = cart.reduce((acc, curr) => acc + curr.quantity, 0);

  const tabs = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'services', label: 'Rituals', icon: Sparkles },
    { id: 'cart', label: 'Cart', icon: ShoppingBag, badge: cartCount },
    { id: 'booking', label: 'Schedule', icon: Calendar },
    { id: 'profile', label: 'Me', icon: User },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-3xl border-t border-rose-100/20 px-4 py-3 pb-[env(safe-area-inset-bottom,16px)] shadow-[0_-15px_40px_rgba(251,207,232,0.15)] rounded-t-[3rem]">
      <div className="flex justify-around items-center max-w-md mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentPage === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onNavigate(tab.id)}
              className="flex flex-col items-center gap-1.5 transition-all flex-1 py-1 relative"
            >
              <div className={`p-3 rounded-[1.6rem] transition-all duration-500 ease-out ${
                isActive 
                  ? 'bg-gradient-to-br from-rose-400 to-rose-500 text-white shadow-[0_10px_20px_-5px_rgba(244,114,182,0.6)] -translate-y-4' 
                  : 'text-slate-400 active:bg-rose-50/50 active:scale-90'
              }`}>
                <Icon className={`${isActive ? 'w-5 h-5' : 'w-5 h-5'} transition-all`} />
                {!isActive && tab.badge && tab.badge > 0 && (
                  <span className="absolute top-1 right-2 w-4 h-4 bg-rose-500 text-white text-[8px] font-black rounded-full flex items-center justify-center border-2 border-white shadow-sm">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className={`text-[10px] font-bold tracking-tight transition-all duration-300 ${isActive ? 'text-rose-500' : 'text-slate-400'}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default BottomTabNav;
