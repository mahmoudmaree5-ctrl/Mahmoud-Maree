
import React from 'react';
import { Home, Sparkles, Newspaper, User } from 'lucide-react';

interface MobileNavProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

const MobileNav: React.FC<MobileNavProps> = ({ onNavigate, currentPage }) => {
  const tabs = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'services', label: 'Rituals', icon: Sparkles },
    { id: 'news', label: 'News', icon: Newspaper },
    { id: 'profile', label: 'Account', icon: User },
  ];

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-2xl border-t border-rose-100 px-4 py-3 pb-safe-area shadow-[0_-8px_30px_rgba(251,207,232,0.15)] rounded-t-[2rem]">
      <div className="flex justify-around items-center max-w-md mx-auto relative">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentPage === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onNavigate(tab.id)}
              className="flex flex-col items-center gap-1 transition-all flex-1 py-1"
            >
              <div className={`p-2.5 rounded-2xl transition-all duration-300 ${
                isActive 
                  ? 'bg-rose-500 text-white shadow-xl shadow-rose-200 -translate-y-2' 
                  : 'text-slate-400 hover:text-rose-300'
              }`}>
                <Icon className="w-5 h-5" />
              </div>
              <span className={`text-[9px] font-black uppercase tracking-tighter transition-all duration-300 ${isActive ? 'text-rose-500' : 'text-slate-400'}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default MobileNav;
