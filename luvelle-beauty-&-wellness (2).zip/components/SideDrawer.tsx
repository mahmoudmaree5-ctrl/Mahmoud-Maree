
import React from 'react';
import { X, Sparkles, Heart, Star, ShoppingBag, ArrowRight, Share2 } from 'lucide-react';

interface SideDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (page: string) => void;
  onShare?: () => void;
}

const SideDrawer: React.FC<SideDrawerProps> = ({ isOpen, onClose, onNavigate, onShare }) => {
  if (!isOpen) return null;

  const quickLinks = [
    { id: 'services', label: 'All Rituals', icon: Sparkles },
    { id: 'offers', label: 'Seasonal Offers', icon: Star },
    { id: 'cart', label: 'My Bag', icon: ShoppingBag },
  ];

  return (
    <div className="fixed inset-0 z-[60] flex">
      <div 
        className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity duration-500" 
        onClick={onClose} 
      />
      
      <div className="relative w-72 bg-[#FFFBFD] h-full shadow-2xl flex flex-col animate-slide-in-left p-8 rounded-r-[3rem] overflow-hidden">
        <div className="absolute top-[-40px] left-[-40px] w-56 h-56 bg-rose-50 rounded-full blur-3xl opacity-50" />
        
        <div className="relative z-10 flex justify-between items-center mb-12">
          <div className="flex flex-col">
            <div className="font-serif font-black text-rose-500 text-2xl tracking-tighter">LUVELLE</div>
            <div className="text-[9px] font-black text-rose-300 uppercase tracking-widest mt-0.5">Sanctuary Menu</div>
          </div>
          <button 
            onClick={onClose} 
            className="p-2.5 bg-white border border-rose-50 text-rose-400 rounded-2xl shadow-sm active-scale"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="relative z-10 flex-1 space-y-3">
          <p className="px-4 text-[10px] font-black text-slate-300 uppercase tracking-[0.2em] mb-4">Quick Access</p>
          {quickLinks.map((item) => (
            <button
              key={item.id}
              onClick={() => { onNavigate(item.id); onClose(); }}
              className="w-full flex items-center justify-between p-5 bg-white border border-rose-50/50 rounded-2xl transition-all group active-scale"
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-rose-50 rounded-xl flex items-center justify-center text-rose-400 group-hover:bg-rose-500 group-hover:text-white transition-all">
                  <item.icon className="w-4 h-4" />
                </div>
                <span className="text-sm font-bold text-slate-700 tracking-tight">{item.label}</span>
              </div>
              <ArrowRight className="w-4 h-4 text-rose-100 group-hover:text-rose-400 transition-all" />
            </button>
          ))}
          
          <button
            onClick={() => { onShare?.(); onClose(); }}
            className="w-full flex items-center justify-between p-5 bg-rose-500/5 border border-rose-500/10 rounded-2xl transition-all group active-scale mt-4"
          >
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-rose-500 text-white rounded-xl flex items-center justify-center">
                <Share2 className="w-4 h-4" />
              </div>
              <span className="text-sm font-bold text-rose-600 tracking-tight">Share Luvelle</span>
            </div>
            <ArrowRight className="w-4 h-4 text-rose-400 transition-all" />
          </button>
        </nav>

        <div className="relative z-10 mt-auto pt-8 border-t border-rose-50 flex flex-col items-center gap-4 text-center">
          <div className="p-4 bg-rose-50/50 rounded-2xl border border-rose-100/50 w-full">
            <Heart className="w-5 h-5 text-rose-400 mx-auto mb-2" />
            <p className="text-[10px] font-bold text-slate-500 uppercase leading-relaxed">Experience Premium Home Sanctuary</p>
          </div>
          <p className="text-[9px] text-slate-300 font-bold uppercase tracking-widest">v1.2.0 Rose Gold</p>
        </div>
      </div>
    </div>
  );
};

export default SideDrawer;
