
import React from 'react';
import { X, Minus, Plus, Trash2, Calendar, ShoppingBag as BagIcon } from 'lucide-react';
import { useApp } from '../AppContext';

const CartDrawer: React.FC<{ onCheckout: () => void }> = ({ onCheckout }) => {
  const { cart, isCartOpen, setIsCartOpen, updateQuantity, removeFromCart } = useApp();
  const total = cart.reduce((acc, curr) => acc + (curr.price * curr.quantity), 0);

  if (!isCartOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div 
        className="absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity"
        onClick={() => setIsCartOpen(false)}
      />
      
      <div className="relative w-full max-w-md bg-[#FFFBFD] h-[95vh] mt-[5vh] rounded-t-[3rem] lg:h-full lg:mt-0 lg:rounded-none shadow-2xl flex flex-col animate-slide-in-right">
        <div className="p-8 pb-4 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-serif font-bold text-slate-800 tracking-tighter uppercase">Your Rituals</h2>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Sanctuary Prep</p>
          </div>
          <button onClick={() => setIsCartOpen(false)} className="p-2.5 bg-rose-50 text-rose-500 rounded-2xl transition-all hover:bg-rose-100">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-8 space-y-6 no-scrollbar">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-6">
              <div className="w-24 h-24 bg-rose-50 rounded-[2rem] flex items-center justify-center border border-rose-100 shadow-inner">
                <BagIcon className="w-10 h-10 text-rose-200" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-serif font-bold text-slate-700 uppercase tracking-tighter">Sanctuary Empty</h3>
                <p className="text-xs text-slate-400 font-medium">Add some luxury to your journey.</p>
              </div>
              <button 
                onClick={() => setIsCartOpen(false)}
                className="w-full py-5 bg-rose-500 text-white rounded-[2rem] font-bold shadow-xl shadow-rose-200"
              >
                Browse Rituals
              </button>
            </div>
          ) : (
            cart.map((item) => (
              <div key={item.id} className="flex gap-4 p-4 bg-white rounded-3xl border border-rose-50 shadow-sm relative overflow-hidden group">
                <div className="w-20 h-20 rounded-2xl overflow-hidden bg-slate-100 flex-shrink-0 shadow-sm">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 flex flex-col justify-between">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-bold text-slate-800 text-sm leading-tight">{item.name}</h4>
                      <p className="text-[10px] text-slate-400 font-bold tracking-widest uppercase mt-0.5">{item.duration}</p>
                    </div>
                    <button onClick={() => removeFromCart(item.id)} className="text-slate-300 hover:text-red-400 transition-colors p-1">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <div className="flex items-center bg-rose-50 rounded-xl p-1 px-1.5 border border-rose-100">
                      <button 
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="p-1 text-rose-400 hover:text-rose-600"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="mx-3 text-xs font-black text-rose-600">{item.quantity}</span>
                      <button 
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="p-1 text-rose-400 hover:text-rose-600"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                    <span className="font-black text-rose-600 text-base">${item.price * item.quantity}</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {cart.length > 0 && (
          <div className="p-8 pt-6 border-t border-rose-100 space-y-5 bg-white rounded-t-[3rem] shadow-[0_-10px_40px_rgba(0,0,0,0.03)]">
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold uppercase tracking-widest">
                <span className="text-slate-400">Total Rituals</span>
                <span className="text-slate-800">${total}</span>
              </div>
              <div className="flex justify-between text-xs font-bold uppercase tracking-widest border-b border-rose-50 pb-2">
                <span className="text-slate-400">Conciege Fee</span>
                <span className="text-slate-800">$10</span>
              </div>
              <div className="flex justify-between text-xl font-serif font-bold pt-2">
                <span className="text-slate-800 uppercase tracking-tighter">Total</span>
                <span className="text-rose-600">${total + 10}</span>
              </div>
            </div>
            
            <button 
              onClick={() => { setIsCartOpen(false); onCheckout(); }}
              className="w-full py-5 bg-rose-500 text-white rounded-[2rem] font-bold flex items-center justify-center gap-3 shadow-2xl shadow-rose-200 hover:bg-rose-600 transition-all hover:translate-y-[-2px] active:scale-95"
            >
              <Calendar className="w-5 h-5" />
              Schedule Sanctuary
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CartDrawer;
