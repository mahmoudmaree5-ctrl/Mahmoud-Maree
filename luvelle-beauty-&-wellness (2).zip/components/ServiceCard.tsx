
import React from 'react';
import { ShoppingBag, Clock, Heart, Sparkles, MessageCircle } from 'lucide-react';
import { Service } from '../types';
import LuxeImage from './LuxeImage';

interface ServiceCardProps {
  service: Service;
  onClick: () => void;
  onAddToCart: (e: React.MouseEvent) => void;
  onWhatsAppClick: (e: React.MouseEvent) => void;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ 
  service, 
  onClick, 
  onAddToCart, 
  onWhatsAppClick 
}) => {
  const discountPercentage = service.originalPrice 
    ? Math.round(((service.originalPrice - service.price) / service.originalPrice) * 100) 
    : 0;

  return (
    <div 
      onClick={onClick}
      className="group relative flex flex-col bg-gradient-to-b from-white to-rose-50/30 rounded-[2.25rem] overflow-hidden border border-rose-100/50 shadow-[0_20px_50px_-20px_rgba(251,207,232,0.5)] active-scale cursor-pointer transition-all duration-500 hover:shadow-[0_30px_60px_-15px_rgba(251,207,232,0.6)]"
    >
      {/* Image Section */}
      <div className="relative h-72 w-full overflow-hidden rounded-t-[2.25rem]">
        <LuxeImage 
          src={service.image} 
          alt={service.name} 
          className="w-full h-full transition-transform duration-1000 group-hover:scale-110" 
        />
        
        {/* Badges */}
        <div className="absolute top-6 left-6 flex flex-wrap gap-2">
          <span className="px-4 h-[28px] flex items-center bg-white/90 backdrop-blur-md rounded-full text-[9px] font-black text-rose-500 uppercase tracking-widest shadow-sm">
            {service.category}
          </span>
          {service.originalPrice && (
            <span className="px-4 h-[28px] flex items-center bg-rose-500 rounded-full text-[9px] font-black text-white uppercase tracking-widest shadow-lg flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> {discountPercentage}% Off
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button 
          onClick={(e) => { e.stopPropagation(); }}
          className="absolute top-6 right-6 w-[44px] h-[44px] flex items-center justify-center bg-white/90 backdrop-blur-md rounded-full text-rose-300 shadow-md active-scale transition-colors hover:text-rose-500"
        >
           <Heart className="w-5 h-5" />
        </button>

        {/* Floating Price Tag */}
        <div className="absolute bottom-6 right-6 flex flex-col items-end gap-1">
          {service.originalPrice && (
            <span className="text-sm font-bold text-white line-through opacity-70 drop-shadow-md">
              ${service.originalPrice}
            </span>
          )}
          <div className="bg-rose-500 px-7 h-[48px] flex items-center rounded-2xl text-white font-black text-lg shadow-2xl border border-white/20">
            ${service.price}
          </div>
        </div>
      </div>

      {/* Content Section */}
      <div className="p-8 lg:p-10 space-y-6">
        <div className="space-y-2">
          <h3 className="text-2xl font-serif font-black text-slate-800 leading-tight tracking-tighter uppercase group-hover:text-rose-500 transition-colors">
            {service.name}
          </h3>
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-400 uppercase tracking-widest">
            <Clock className="w-4 h-4 text-rose-300" /> {service.duration}
          </div>
        </div>
        
        <p className="text-[14px] text-slate-500 leading-relaxed font-medium line-clamp-2">
          {service.description}
        </p>
        
        {/* Action Buttons */}
        <div className="grid grid-cols-1 gap-3 pt-2">
          <button 
            onClick={onAddToCart}
            className="w-full h-[60px] flex items-center justify-center gap-3 bg-gradient-to-r from-rose-400 to-rose-600 text-white rounded-[1.8rem] text-[11px] font-black uppercase tracking-[0.2em] shadow-xl shadow-rose-200 active-scale"
          >
            <ShoppingBag className="w-5 h-5" /> Add to Bag
          </button>
          <button 
            onClick={onWhatsAppClick}
            className="w-full h-[60px] flex items-center justify-center gap-3 bg-white border border-[#25D366]/30 text-[#25D366] rounded-[1.8rem] text-[11px] font-black uppercase tracking-[0.2em] active-scale hover:bg-[#25D366]/5 transition-colors"
          >
            <MessageCircle className="w-5 h-5" /> Book via WhatsApp
          </button>
        </div>
      </div>
    </div>
  );
};

export default ServiceCard;
