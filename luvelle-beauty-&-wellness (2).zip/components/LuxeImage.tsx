
import React, { useState } from 'react';

interface LuxeImageProps {
  src: string;
  alt: string;
  className?: string;
}

const LuxeImage: React.FC<LuxeImageProps> = ({ src, alt, className = "" }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState(false);

  const fallbackImage = "https://images.unsplash.com/photo-1560750588-73207b1ef5b8?w=800&fit=crop";

  return (
    <div className={`relative overflow-hidden bg-rose-50 ${className}`}>
      {!isLoaded && !error && (
        <div className="absolute inset-0 skeleton" />
      )}
      <img
        src={error ? fallbackImage : src}
        alt={alt}
        className={`w-full h-full object-cover transition-opacity duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}
        onLoad={() => setIsLoaded(true)}
        onError={() => setError(true)}
      />
    </div>
  );
};

export default LuxeImage;
