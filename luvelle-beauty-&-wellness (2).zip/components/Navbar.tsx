
import React from 'react';
import { ShoppingBag, Search } from 'lucide-react';
import { useApp } from '../AppContext';

interface NavbarProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate, currentPage }) => {
  const { cart, setIsCartOpen } = useApp();
  const cartCount = cart.reduce((acc, curr) => acc + curr.quantity, 0);

  const navLinks = [
    { name: 'Home', id: 'home' },
    { name: 'Services', id: 'services' },
    { name: 'Offers', id: 'offers' },
    { name: 'About', id: 'about' },
    { name: 'Contact', id: 'contact' },
  ];

  return (
    <nav className="sticky top-0 z-40 w-full bg-white/80 backdrop-blur-md border-b border-rose-100 px-6 py-4 md:px-12 flex items-center justify-between">
      <div className="flex items-center gap-8">
        <button 
          onClick={() => onNavigate('home')}
          className="text-2xl font-serif font-bold text-rose-500 tracking-tighter"
        >
          LUVELLE
        </button>
        {/* Desktop Links */}
        <div className="hidden lg:flex items-center gap-8">
          {navLinks.map(link => (
            <button
              key={link.id}
              onClick={() => onNavigate(link.id)}
              className={`text-sm font-semibold transition-colors hover:text-rose-500 ${
                currentPage === link.id ? 'text-rose-600' : 'text-slate-500'
              }`}
            >
              {link.name}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className="hidden md:flex items-center px-4 py-2 bg-rose-50/50 rounded-2xl border border-rose-100 mr-2">
          <Search className="w-4 h-4 text-rose-300" />
          <input 
            type="text" 
            placeholder="Search luxe..." 
            className="bg-transparent border-none outline-none text-xs ml-2 w-32 placeholder:text-rose-300"
          />
        </div>
        
        <button 
          onClick={() => setIsCartOpen(true)}
          className="relative p-2.5 bg-rose-500 text-white rounded-2xl hover:bg-rose-600 transition-all transform hover:scale-105 shadow-md shadow-rose-200"
        >
          <ShoppingBag className="w-5 h-5" />
          {cartCount > 0 && (
            <span className="absolute -top-1.5 -right-1.5 bg-white text-rose-600 text-[10px] font-black w-5 h-5 flex items-center justify-center rounded-full border-2 border-rose-500">
              {cartCount}
            </span>
          )}
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
