
import { CartItem } from '../types';

export const getWhatsAppLink = (items: CartItem[], date?: string, time?: string) => {
  const phoneNumber = "1234567890"; // Brand's official number
  const serviceNames = items.map(i => `${i.name} (x${i.quantity})`).join(", ");
  const total = items.reduce((acc, curr) => acc + (curr.price * curr.quantity), 0);
  
  let message = `Hi Luvelle! 🎀\n\nI'd like to book the following rituals:\n${serviceNames}\n\n`;
  if (date && time) {
    message += `Requested Slot: ${date} at ${time}\n`;
  }
  message += `Total Estimate: $${total + 10}\n\nLooking forward to my home sanctuary session! ✨`;
  
  return `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
};
