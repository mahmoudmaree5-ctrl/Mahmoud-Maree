
import { Service, Blog, Offer } from './types';

export const SERVICES: Service[] = [
  {
    id: '1',
    name: 'Royal Blowout',
    description: 'Signature luxury hair styling with premium products for a flawless finish.',
    price: 120,
    originalPrice: 150,
    duration: '45 mins',
    category: 'Hair',
    image: 'https://images.unsplash.com/photo-1522337363553-5605d9308ee7?w=600&fit=crop'
  },
  {
    id: '2',
    name: 'Caviar Hair Treatment',
    description: 'Deep conditioning treatment using rare ingredients to restore shine and health.',
    price: 280,
    duration: '60 mins',
    category: 'Hair',
    image: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=600&fit=crop'
  },
  {
    id: '3',
    name: 'Gel Luxe Manicure',
    description: 'Long-lasting gel polish with luxury hand massage and cuticle care.',
    price: 95,
    originalPrice: 120,
    duration: '50 mins',
    category: 'Nails',
    image: 'https://images.unsplash.com/photo-1604654894610-df63bc536371?w=600&fit=crop'
  },
  {
    id: '4',
    name: 'Ethereal Pedicure',
    description: 'Soothing foot soak, exfoliation, and elegant polish.',
    price: 140,
    duration: '60 mins',
    category: 'Nails',
    image: 'https://images.unsplash.com/photo-1519014816548-bf5fe059798b?w=600&fit=crop'
  },
  {
    id: '5',
    name: 'Aromatherapy Massage',
    description: 'Stress-relieving full body massage with essential oil blends.',
    price: 290,
    originalPrice: 350,
    duration: '90 mins',
    category: 'Massage',
    image: 'https://images.unsplash.com/photo-1544161515-4af6b1d46af0?w=600&fit=crop'
  },
  {
    id: '6',
    name: 'The Ultimate Glow Package',
    description: 'Full hair blowout, luxury manicure, and 30-min express massage.',
    price: 490,
    originalPrice: 550,
    duration: '180 mins',
    category: 'Packages',
    image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=600&fit=crop'
  }
];

export const OFFERS: Offer[] = [
  {
    id: 'o1',
    title: 'First Time Joy',
    description: '20% off your first home service booking.',
    code: 'WELCOME20',
    discount: '20%',
    image: 'https://picsum.photos/seed/offer1/800/400'
  },
  {
    id: 'o2',
    title: 'BFF Pamper Day',
    description: 'Book for two and get 15% off both services.',
    code: 'BFF15',
    discount: '15%',
    image: 'https://picsum.photos/seed/offer2/800/400'
  }
];

export const BLOGS: Blog[] = [
  {
    id: 'b1',
    title: 'Self-Care Sundays: The Luvelle Way',
    excerpt: 'Discover the art of creating a sanctuary at home...',
    content: 'Creating a home sanctuary starts with intention. Our lead wellness director, Elena Rose, suggests focusing on the five senses. Begin by diffusing signature Luvelle lavender oils (Ambiance Preference) and setting the lighting to a warm amber. When our artisans arrive, they bring this philosophy to life through touch and expert craft. Learn how to maintain your glow between rituals with our new line of botanical elixirs.',
    author: 'Elena Rose',
    date: 'Oct 24, 2024',
    image: 'https://images.unsplash.com/photo-1515377905703-c4788e51af15?w=600&fit=crop'
  },
  {
    id: 'b2',
    title: '5 Secrets to Lasting Hair Shine',
    excerpt: 'Our lead stylists reveal their top tips for radiant hair...',
    content: 'Hair health is an internal and external journey. Stylist Marcus J. recommends silk pillowcases and cold-water rinses to seal the cuticle. But the real secret? Our Caviar Treatment ritual, which penetrates deep into the follicle. Explore the science of luxury hair care in this deep dive into our signature products.',
    author: 'Marcus J.',
    date: 'Nov 02, 2024',
    image: 'https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?w=600&fit=crop'
  }
];
